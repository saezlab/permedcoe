/*

 
    Ant Colony Optimization for the CellNopt
 
    patricia.gonzalez@udc.es

 
 
***************************************************************************/


#include <stdio.h>
#include <math.h>
#include <limits.h>
#include <assert.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>

#include "aco.hpp"

int termination_condition( void )
/*    
      FUNCTION:       checks whether termination condition is met 
      INPUT:          none
      OUTPUT:         0 if condition is not met, number neq 0 otherwise
      (SIDE)EFFECTS:  none
*/
{
  return ( ((iteration >= max_iters) || (elapsed_time( REAL ) >= max_time)) ||
	  (best_so_far_ant->score <= optimal));
}



void construct_solutions( void )
/*    
      FUNCTION:       manage the solution construction phase
      INPUT:          none
      OUTPUT:         none
      (SIDE)EFFECTS:  when finished, all ants of the colony have constructed a solution  
*/
{
    int k;        /* counter variable */
    int step;    /* counter of the number of construction steps */


    for ( k = 0 ; k < n_ants ; k++ ) {
        step = 0;
        while ( step < n ) {
            select_gate( &ant[k], step);
            step++;
        }
    }
 
}



void init_cellnopt_aco( void )
/*    
      FUNCTION: initilialize variables appropriately when starting a trial
      INPUT:    none
      OUTPUT:   none
      COMMENTS: none
*/
{
    int  i;

    set_default_parameters();

    /* Allocate ants */
    allocate_ants();

    /* Initialize variables concerning statistics etc. */
    iteration    = 1;
    best_iteration = 1;
    restart_best = 1;
    best_so_far_ant->score = INFTY;
    
    start_timers();
    best_time = 0.0;
    time_used = elapsed_time( REAL );
    time_passed = time_used;
   
    /* Initialize the solutions for the ants */
    place_ants();
    
    /* allocate pheromone matrix */
    pheromone = generate_double_matrix( n, 2 );
    total = generate_double_matrix( n, 2 );

    /* Initialize pheromone trails */
    if (mmas_flag) {
        trail_max = 1. / ( (rho) * 0.5 );
        trail_min = trail_max / ( 2. * n );
        trail_0 = trail_max;
        init_pheromone_trails( trail_0 );
    }
    else {
        trail_0 = 0;
        init_pheromone_trails( trail_0 );
    }

}

void exit_cellnopt_aco( void )
/*
 FUNCTION: end trial
 INPUT:    none
 OUTPUT:   none
 COMMENTS: none
 */
{
 
    int     i;
    
    write_report();

    free( pheromone );
    free( total );
    for ( i = 0 ; i < n_ants ; i++ ) 
        free( ant[i].solution );
    free( ant );
    free( best_so_far_ant->solution );

}
    
void update_statistics( void )
/*    
      FUNCTION:       manage some statistical information about the trial, especially
                      if a new best solution (best-so-far or restart-best) is found and
                      adjust some parameters if a new best solution is found
      INPUT:          none
      OUTPUT:         none
      (SIDE)EFFECTS:  restart-best and best-so-far ant may be updated; trail_min 
                      and trail_max used by MMAS may be updated
*/
{

    int i, iteration_best_ant;

    iteration_best_ant = find_best(); /* iteration_best_ant is a global variable */

    if ( ant[iteration_best_ant].score < best_so_far_ant->score ) {
        
        time_used = elapsed_time( REAL ); /* best sol found after time_used */
        copy_from_to( &ant[iteration_best_ant], best_so_far_ant );
        
        best_iteration = iteration;
        restart_best = iteration;
        best_time = time_used;

         if ( mmas_flag ) {
            trail_max = 1. / ( (rho) * best_so_far_ant->score );
            trail_min = trail_max / ( 2. * n );
            trail_0 = trail_max;
            
        }

        printf("Try: %d, found best %f, iteration: %d, time %.2f\n",ntry,best_so_far_ant->score,iteration,elapsed_time( REAL));
        printSolution(best_so_far_ant->solution);
        
        if (report){
            fprintf(report,
                    "iteration %d\t time %.3f \t best %f [ ",
                    iteration,time_used,best_so_far_ant->score);
            for (i=0 ; i<n ; i++) fprintf(report,"%d ",best_so_far_ant->solution[i]);
            fprintf(report,"]\n");
        }

    }
   
    if ( mmas_flag && (iteration - restart_best > restart_iters) ) {
        /* MAX-MIN Ant System was the first ACO algorithm to use
         pheromone trail re-initialisation as implemented
         here. Other ACO algorithms may also profit from this mechanism.
         */
        printf("Try %d, INIT TRAILS!!! Iteration %d\n", ntry,iteration);
        init_pheromone_trails( trail_0 );
        compute_total_information();
        restart_best = iteration;
        restart_time = elapsed_time( VIRTUAL );
    }
    
}


void pheromone_trail_update( void )  
/*    
      FUNCTION:       manage global pheromone trail update for the ACO algorithms
      INPUT:          none
      OUTPUT:         none
      (SIDE)EFFECTS:  pheromone trails are evaporated and pheromones are deposited 
 
*/
{
    int     k;
   
    /* Simulate the pheromone evaporation of all pheromones */
    evaporation();

    /* Apply the pheromone deposit for different ACO variants */
    if (mmas_flag) mmas_update();
    else if (eas_flag) eas_update();
    else as_update();

    /* Check pheromone trail limits for MMAS */
    if ( mmas_flag )
        check_pheromone_trail_limits();
    
  /* Compute combined information pheromone times heuristic info after
     the pheromone update  */
    compute_total_information();

}

void as_update( void )
/*
 FUNCTION:       manage global pheromone deposit for Ant System
 INPUT:          none
 OUTPUT:         none
 (SIDE)EFFECTS:  all ants deposit pheromones on matrix "pheromone"
 */
{
    int   k;
    
    for ( k = 0 ; k < n_ants ; k++ )
        global_update_pheromone( &ant[k] );
    
}



void eas_update( void )
/*
 FUNCTION:       manage global pheromone deposit for Elitist Ant System
 INPUT:          none
 OUTPUT:         none
 (SIDE)EFFECTS:  best ant so far deposit more pheromone
 */
{
    int   k;
    
    for ( k = 0 ; k < n_ants ; k++ )
        global_update_pheromone( &ant[k] );

    global_update_pheromone_weighted( best_so_far_ant, 2 );
    
}


void mmas_update( void )
/*
 FUNCTION:       manage global pheromone deposit for MAX-MIN Ant System
 INPUT:          none
 OUTPUT:         none
 (SIDE)EFFECTS:  either the iteration-best or the best-so-far ant deposit pheromone
 on matrix "pheromone"
 */
{
    
    int iteration_best_ant;
   
    if ( iteration % u_gb ) {
        iteration_best_ant = find_best();
        global_update_pheromone( &ant[iteration_best_ant] );
    }
    else {
        global_update_pheromone( best_so_far_ant );
    }
    
    
    if ( ( iteration - restart_best ) < (int)(restart_iters/10) )
        u_gb = 10;
    else if ( (iteration - restart_best) < (int)(restart_iters/2) )
        u_gb = 5;
    else if ( (iteration - restart_best) < (int)(restart_iters/1.3) )
        u_gb = 3;
    else if ( (iteration - restart_best) < restart_iters )
        u_gb = 2;
    else
        u_gb = 1;

    
}



