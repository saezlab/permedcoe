/*
 
 
 Ant Colony Optimization for the CellNopt
 
 patricia.gonzalez@udc.es
 
 
 
 ***************************************************************************/


#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include <sys/time.h>
#include <sys/resource.h>

#include "aco.hpp"

int iteration;         /* iteration counter */
int best_iteration;
int restart_best;
int restart_iters;

int max_iters;         /* maximum number of iterations */
long int seed;

double   max_time;          /* maximal allowed run time of a try  */
double   time_used;         /* time used until some given event */
double   time_passed;       /* time passed until some moment*/
double 	 best_time;
double 	 restart_time;

double optimal;           /* optimal solution or bound to find */

int *optimal_solution; /* optimal solution for a test problem */

/* ------------------------------------------------------------------------ */

FILE *report, *final_report;

char name_buf[LINE_BUF_LEN];
int  opt;


/**************************   TIMER  ***************************************/
static struct rusage res;
static struct timeval tp;
static double virtual_time, real_time;

void start_timers(void)
/*
 FUNCTION:       virtual and real time of day are computed and stored to
 allow at later time the computation of the elapsed time
 (virtual or real)
 INPUT:          none
 OUTPUT:         none
 (SIDE)EFFECTS:  virtual and real time are computed
 */
{
    getrusage( RUSAGE_SELF, &res );
    virtual_time = (double) res.ru_utime.tv_sec +
    (double) res.ru_stime.tv_sec +
    (double) res.ru_utime.tv_usec / 1000000.0 +
    (double) res.ru_stime.tv_usec / 1000000.0;
    
    gettimeofday( &tp, NULL );
    real_time =    (double) tp.tv_sec +
    (double) tp.tv_usec / 1000000.0;
}



double elapsed_time(TIMER_TYPE type)
/*
 FUNCTION:       return the time used in seconds (virtual or real, depending on type)
 INPUT:          TIMER_TYPE (virtual or real time)
 OUTPUT:         seconds since last call to start_timers (virtual or real)
 (SIDE)EFFECTS:  none
 */
{
    if (type == REAL) {
        gettimeofday( &tp, NULL );
        return( (double) tp.tv_sec +
               (double) tp.tv_usec / 1000000.0
               - real_time );
    }
    else {
        getrusage( RUSAGE_SELF, &res );
        return( (double) res.ru_utime.tv_sec +
               (double) res.ru_stime.tv_sec +
               (double) res.ru_utime.tv_usec / 1000000.0 +
               (double) res.ru_stime.tv_usec / 1000000.0
               - virtual_time );
    }
    
}

/**************************   STATISTICS  ***************************************/

double ran01( long *idum )
/*    
      FUNCTION:       generate a random number that is uniformly distributed in [0,1]
      INPUT:          pointer to variable with the current seed
      OUTPUT:         random number uniformly distributed in [0,1]
      (SIDE)EFFECTS:  random number seed is modified (important, this has to be done!)
      ORIGIN:         numerical recipes in C
*/
{
  long k;
  double ans;

  k =(*idum)/IQ;
  *idum = IA * (*idum - k * IQ) - IR * k;
  if (*idum < 0 ) *idum += IM;
  ans = AM * (*idum);
  return ans;
}



long int random_number( long *idum )
/*    
      FUNCTION:       generate an integer random number
      INPUT:          pointer to variable containing random number seed
      OUTPUT:         integer random number uniformly distributed in {0,2147483647}
      (SIDE)EFFECTS:  random number seed is modified (important, has to be done!)
      ORIGIN:         numerical recipes in C
*/
{
  long int k;

  k =(*idum)/IQ;
  *idum = IA * (*idum - k * IQ) - IR * k;
  if (*idum < 0 ) *idum += IM;
  return *idum;
}



int ** generate_int_matrix( int n, int m)
/*    
      FUNCTION:       malloc a matrix and return pointer to it
      INPUT:          size of matrix as n x m 
      OUTPUT:         pointer to matrix
      (SIDE)EFFECTS:  
*/
{
  int i;
  int **matrix;

  if((matrix = (int**) malloc(sizeof(int) * n * m +
		      sizeof(int *) * n	 )) == NULL){
    printf("Out of memory, exit.");
    exit(1);
  }
  for ( i = 0 ; i < n ; i++ ) {
    matrix[i] = (int *)(matrix + n) + i*m;
  }

  return matrix;
}



double ** generate_double_matrix( int n, int m)
/*    
      FUNCTION:       malloc a matrix and return pointer to it
      INPUT:          size of matrix as n x m 
      OUTPUT:         pointer to matrix
      (SIDE)EFFECTS:  
*/
{

  int i;
  double **matrix;

  if((matrix = (double**) malloc(sizeof(double) * n * m +
		      sizeof(double *) * n	 )) == NULL){
    printf("Out of memory, exit.");
    exit(1);
  }
  for ( i = 0 ; i < n ; i++ ) {
    matrix[i] = (double *)(matrix + n) + i*m;
  }
  return matrix;
}



/**************************   IN-OUT  ***************************************/


void init_report( void )
/*
 FUNCTION:       prepare report file,
 INPUT:          none
 OUTPUT:         none
 COMMENTS:
 */
{
    char temp_buffer[LINE_BUF_LEN];
    
    sprintf(temp_buffer,"conv_report");
    report = fopen(temp_buffer, "w");
    sprintf(temp_buffer,"final_report");
    final_report = fopen(temp_buffer, "w");
}


void set_default_parameters(void)
/*
 FUNCTION: set default parameter settings
 INPUT:    none
 OUTPUT:   none
 COMMENTS: none
 */
{
    n_ants         = 16;    /* number of ants */
    alpha          = 1.0;
    beta           = 2.0;
    rho            = 0.5;
    q_0            = 0.0;
    max_iters      = 1000;
    seed           = (long int) time(NULL)*(ntry+1);
    max_time       = 10.0;
    optimal        = 0.029643;
    as_flag        = 0;
    eas_flag       = 0;
    mmas_flag      = 1;
    u_gb	   = 10;
    restart_iters  = 100;
}


void print_parameters()
/*
 FUNCTION: print parameter settings
 INPUT:    none
 OUTPUT:   none
 COMMENTS: none
 */
{
    printf("\n Parameter settings are:\n");
    printf("max_iters\t\t %d\n", max_iters);
    printf("max_time\t\t %.2f\n", max_time);
    printf("seed\t\t %ld\n", seed);
    printf("optimum\t\t\t %f\n", optimal);
    printf("n_ants\t\t\t %d\n", n_ants);
    printf("alpha\t\t\t %.2f\n", alpha);
    printf("beta\t\t\t %.2f\n", beta);
    printf("rho\t\t\t %.2f\n", rho);
    printf("q_0\t\t\t %.2f\n", q_0);
}


void printSolution( int *t )
/*
 FUNCTION:       print the solution *t
 INPUT:          pointer to a solution
 OUTPUT:         none
 */
{
    int   i;
    
    printf("[ ");
    for( i = 0 ; i < n ; i++ ) {
        printf("%d ", t[i]);
    }
    printf(" ]\n");
}


void write_report( void )
/*
 FUNCTION:       write report file
 INPUT:          pointer to a solution
 OUTPUT:         none
 */
{
	int  i;

        if (final_report){
            fprintf(final_report,
                    "Try %d:\t iteration %d\t time %.3f \t evaluations %d \t best %f \t[ ",
                    ntry,best_iteration,best_time,iteration*n_ants,best_so_far_ant->score);
            for (i=0 ; i<n ; i++) fprintf(final_report,"%d ",best_so_far_ant->solution[i]);
            fprintf(final_report,"]\n");
        }

}
