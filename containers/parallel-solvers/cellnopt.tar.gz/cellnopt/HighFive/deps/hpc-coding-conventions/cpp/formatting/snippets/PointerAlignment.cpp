// pointer and reference are part of the type

int* a;
int& b = getB();
