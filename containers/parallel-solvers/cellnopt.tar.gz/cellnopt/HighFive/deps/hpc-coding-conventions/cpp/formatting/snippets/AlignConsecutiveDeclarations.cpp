// Do not align consecutive declarations

int aaaa = 12;
float b = 23;
std::string ccc = 23;
