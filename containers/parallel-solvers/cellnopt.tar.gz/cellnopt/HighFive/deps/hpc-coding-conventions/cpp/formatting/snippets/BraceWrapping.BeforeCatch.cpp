// Do not break before *catch* directive

try {
    foo();
} catch () {
}
