// Brace on same line than *function* definitions

void foo() {
    bar();
    bar2();
}
