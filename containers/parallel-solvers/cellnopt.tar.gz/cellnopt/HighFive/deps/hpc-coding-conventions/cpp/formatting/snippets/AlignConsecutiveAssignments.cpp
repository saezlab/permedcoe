// Do not align consecutive assignments

int aaaa = 12;
int b = 23;
int ccc = 23;
