// Recall namespace when closing it

namespace bbp {
foo();
}
