// No space inside C++11 braced lists

vector<int> x{1, 2, 3, 4};
vector<T> x{{}, {}, {}, {}};
f(MyMap[{composite, key}]) new int[3]{1, 2, 3};
