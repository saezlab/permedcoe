
#ifndef COMPUTESCORET1CARNIVAL
#define COMPUTESCORET1CARNIVAL

#include <algorithm>
#include <iostream>

#include "carnival_data.hpp"
#include "get_fit_carnival.hpp"
#include "carnival_simulator.hpp"


double compute_score_t1_carnival(const Carnival_data& data, 
                        std::vector<int>& bString,
                        int simulation_max_iter=100, 
                        double betaWeight=0.001,
                        double NA_penalty=100, 
                        double cycle_penalty=100,
                        int timeIndex=2) {

    // check for all-0 string, return something big in this case
    int bstring_sum = 0;
    for (const auto& elem : bString) {
           bstring_sum += elem;
    }
    if(bstring_sum == 0) return(1e3); 

    auto interMat = subset_cols(data.interMat, bString);
    auto finalCube = subset_rows(data.finalCube, bString);
    auto ixNeg = subset_rows(data.ixNeg, bString);
    auto ignoreCube = subset_rows(data.ignoreCube, bString);
    auto maxIx = subset_vector(data.maxIx, bString);
    auto nStimuli = data.nStimuli;
    auto nInhibitors = data.nInhibitors;
    auto nCond = data.nCond;
    auto nReacsCut = std::count(bString.begin(), bString.end(), 1);
    auto nReacs = data.nReacs;
    auto nSpecies = data.nSpecies;

    auto nMaxInputs = finalCube[0].size();
    auto indexSignals = data.indexSignals;
    auto indexStimuli = data.indexStimuli;
    auto indexInhibitors = data.indexInhibitors;
    auto nSignals = data.nSignals;
    auto valueInhibitors = data.valueInhibitors;
    auto valueStimuli = data.valueStimuli;
    auto cnolist0 = data.cnolistSignalsT0;
    //auto cnolist1 = data.cnolistSignalsT1;
    int states_in_cycle_detected = 0;
    
    
    // For CARNIVAL we need to evaluate the model at the single timepoint as it was the timepoint 1 (perturbed) in CellNOpt
    auto simResults = carnival_simulator(nStimuli, nInhibitors, nCond, nReacsCut, nSpecies, nSignals, 
                                nMaxInputs, finalCube, ixNeg, ignoreCube, maxIx, indexSignals, 
                                indexStimuli, indexInhibitors, valueInhibitors, valueStimuli, 1, 
                                simulation_max_iter,states_in_cycle_detected);


    /*auto simResultsT0 = carnival_simulator(nStimuli, nInhibitors, nCond, nReacsCut, nSpecies, nSignals, 
                                  nMaxInputs, finalCube, ixNeg, ignoreCube, maxIx, indexSignals, 
                                  indexStimuli, indexInhibitors, valueInhibitors, valueStimuli, 0);*/

    //auto simResultsT0Cut = select_cols(simResultsT0, indexSignals);
    //auto simResultsCut = select_cols(simResults, indexSignals);

    // The comparison of cnolist0 with sinResultsCut is not by mistake, as the data is stored as the first timepoint (cnolist0), but 
    // modelled as the perturbed state. -> some cleaning would be great. 
    double score = get_fit_carnival(nCond, nSignals, simResults, indexSignals,
                           cnolist0, interMat, betaWeight, NA_penalty,
                           cycle_penalty,states_in_cycle_detected);

    
	return score;
}

#endif


