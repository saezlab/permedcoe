
#ifndef GET_FIT_CARNIVAL
#define GET_FIT_CARNIVAL

#include <algorithm>
#include <cmath>
#include <iostream>



// the code is based on the CellNOpt version but CARNIVAL works
// rather differently. 
// instead of edges, the nodes are penalyzed
// there is no NA penalty, but there is a penalty for not fitting the measurement


double get_fit_carnival (int nCond, 
                int nSignals, 
                const std::vector<std::vector<double>>& simResultsAll, // all variables!
                std::vector<int>& indexSignals, 
                const std::vector<std::vector<double>>& cnolist0, 
                const std::vector<std::vector<int>>& interMatCut, 
                double betaWeight,
                double NA_penalty,
                double cycle_penalty,
                int states_in_cycle_detected) {

    int nInputs = 0;
    for (const auto& row : interMatCut) {
        nInputs += std::count(row.begin(), row.end(), -1);
    }
    
    // take the measured signals
    auto simSignals = select_cols(simResultsAll, indexSignals);

    // take the values of non-measured nodes (used for penalty)
    //      set an index vector along all the nodes
    vector<int> indexNodes;
    int n_item = 0;
    const auto row = simResultsAll[0];
    for (const auto& elem : row) {
        indexNodes.push_back(n_item++);
    }

    //      take the difference between indexNodes and indexSignals to get all the non-measured nodes  
    vector<int> indexNonSignals;
    std::sort(indexSignals.begin(), indexSignals.end());
    std::set_difference(indexNodes.begin(), indexNodes.end(), indexSignals.begin(), indexSignals.end(),
        std::inserter(indexNonSignals, indexNonSignals.begin()));

    auto simNonSignals = select_cols(simResultsAll, indexNonSignals);

    // penalize non-measured nodes which have a +1/-1 value: 
    // We also penalize NAs. NAs contribute to size
    int nonZeros = 0;
    int NAs = 0;
    for (const auto& row : simNonSignals) {
        for (const auto& elem : row) {
            if (std::isnan(elem)) {
                NAs += 1;
            }else if(elem != 0.0){
                nonZeros += 1;
            }
        }
    }
    /*std::cout << simResultsAll << std::endl;     

    std::cout << "nodes for penalty: " << std::endl; 
    std::cout << "nonZeros:  " << nonZeros <<std::endl;
    std::cout << "NAs:  " << NAs <<std::endl;*/

    double sizePenalty = betaWeight * nonZeros;    

    double deviationPen = 0;
    double r;

    for (unsigned i = 0; i < nCond; i++) {
	    for (unsigned j = 0; j < nSignals; j++) {
	        // abs deviation penalty, Note, that simSignals has {-1,0,1} values
            r =  abs(cnolist0[i][j]) * abs(simSignals[i][j] - sgn(cnolist0[i][j]));

            if (!std::isnan(r)){
                deviationPen += r;
            }else{
                /* how to handle NA simulation for measured nodes: 
                option A: explicitly with NA_penalty: same penalty for each missing values (CellNOpt style)
                [option B]: penalty is as large as the non-fitted value. [current selection]
                */
                deviationPen += abs(cnolist0[i][j]); //NA_penalty;
            }
        }
    }
    

    
    double score = deviationPen + sizePenalty + states_in_cycle_detected*cycle_penalty;

    return score;

}

#endif
