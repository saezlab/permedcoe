# Benchmark problems
This folder contains the in-silico and real case studies to comapre optimization methods (ACO, GA, ILP) 

Content: 
- `calibrate_insilico_models.R`: driver script to calibrate all in-silico case studies
- `generate_insilico_models.R`: driver script to generate all in-silico case studies
- `RMD_temlate_report_insilico_model.Rmd`:  RMD template to generate report on in-silico case study
- `RMD_template_report_insilico_model_calibration.Rmd`:  RMD template to generate report on the **calibration** of in-silico case study with genetic algorithm
- `calibrate_insilcio_model_v1_XYZ.html`: summary of in-silico case study `XYZ`
- `insilcio_model_v1_XYZ` folders that contain the in-silico case studies
- `insilico_model_generator` folder that contains utility functions for the in-silico model generation
= `toymodel` toy model used on the CellNOptR vignette
