

# generate a series of insilico models by running the template R-markdown

library(here)

# Model 1 -----------------------------------

model_name = "insilcio model v1 N150 M40"

rmarkdown::render(
    here('benchmark/RMD_template_report_insilico_model_calibration.Rmd'),
    output_file = here(file.path("benchmark",paste0("calibrate_",gsub(" ","_",model_name), '.html'))),
    params = list(rnd_seed = 1987,
                  model_name = model_name,
                  sizeFac = 1e-4,
                  maxTime = 120),
    envir = parent.frame()
)


# Model 2  -----------------------------------

model_name = "insilcio model v1 N200 M45"

rmarkdown::render(
    here('benchmark/RMD_template_report_insilico_model_calibration.Rmd'),
    output_file = here(file.path("benchmark",paste0("calibrate_",gsub(" ","_",model_name), '.html'))),
    params = list(rnd_seed = 1987,
                  model_name = model_name,
                  sizeFac = 1e-4,
                  maxTime = 120),
    envir = parent.frame()
)


# Model 3 -----------------------------------

model_name = "insilcio model v1 N300 M55"

rmarkdown::render(
    here('benchmark/RMD_template_report_insilico_model_calibration.Rmd'),
    output_file = here(file.path("benchmark",paste0("calibrate_",gsub(" ","_",model_name), '.html'))),
    params = list(rnd_seed = 1987,
                  model_name = model_name,
                  sizeFac = 1e-4,
                  maxTime = 120),
    envir = parent.frame()
)



# Model 4 -----------------------------------

model_name = "insilcio model v1 N1k M55"

rmarkdown::render(
    here('benchmark/RMD_template_report_insilico_model_calibration.Rmd'),
    output_file = here(file.path("benchmark",paste0("calibrate_",gsub(" ","_",model_name), '.html'))),
    params = list(rnd_seed = 1987,
                  model_name = model_name,
                  sizeFac = 1e-4,
                  maxTime = 120),
    envir = parent.frame()
)


