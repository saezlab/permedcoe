#!/usr/bin/env Rscript

if (!requireNamespace("BiocManager", quietly = TRUE))
    install.packages("BiocManager")
if (!requireNamespace("CellNOptR", quietly = TRUE))
    BiocManager::install("CellNOptR")
if (!requireNamespace("rhdf5", quietly = TRUE))
    BiocManager::install("rhdf5")


library(CellNOptR)
library(rhdf5)

source("R/export_model_to_hdf5.R")



### 2. prepare insiloco model 1.
insilico1_cnolist <- readRDS("./benchmark/insilico_model_1/cnodata.rds")
insilico1_model <- readRDS("./benchmark/insilico_model_1/model.rds")


export_model_to_hdf5(insilico1_cnolist,insilico1_model,"insilico1.h5")
file.copy("./insilico1.h5",to = "benchmark/insilico_model_1/insilico1.h5")
file.remove("./insilico1.h5")



