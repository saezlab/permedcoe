

# generate a series of insilico models by running the template R-markdown

library(here)

# Model 1 -----------------------------------

model_name = "insilcio model v1 N150 M40"

rmarkdown::render(
    here('benchmark/RMD_temlate_report_insilico_model.Rmd'),
    output_file = here(file.path("benchmark",paste0(gsub(" ","_",model_name), '.html'))),
    params = list(rnd_seed = 1987,
                  model_name = model_name,
                  N_nodes = 100,
                  p_neg = 0.01,
                  N_measured = 40,
                  N_stimulated = 6,
                  N_inhibited = 6,
                  cross_talk_ratio = 0.5),
    envir = parent.frame()
)


# Model 2  -----------------------------------

model_name = "insilcio model v1 N200 M45"

rmarkdown::render(
    here('benchmark/RMD_temlate_report_insilico_model.Rmd'),
    output_file = here(file.path("benchmark",paste0(gsub(" ","_",model_name), '.html'))),
    params = list(rnd_seed = 1987,
                  model_name = model_name,
                  N_nodes = 200,
                  p_neg = 0.01,
                  N_measured = 45,
                  N_stimulated = 7,
                  N_inhibited = 6,
                  cross_talk_ratio = 0.5),
    envir = parent.frame()
)


# Model 3 -----------------------------------

model_name = "insilcio model v1 N300 M55"

rmarkdown::render(
    here('benchmark/RMD_temlate_report_insilico_model.Rmd'),
    output_file = here(file.path("benchmark",paste0(gsub(" ","_",model_name), '.html'))),
    params = list(rnd_seed = 1987,
                  model_name = model_name,
                  N_nodes = 300,
                  p_neg = 0.01,
                  N_measured = 55,
                  N_stimulated = 7,
                  N_inhibited = 6,
                  cross_talk_ratio = 0.5),
    envir = parent.frame()
)



# Model 4 -----------------------------------

model_name = "insilcio model v1 N1k M55"

rmarkdown::render(
    here('benchmark/RMD_temlate_report_insilico_model.Rmd'),
    output_file = here(file.path("benchmark",paste0(gsub(" ","_",model_name), '.html'))),
    params = list(rnd_seed = 1987,
                  model_name = model_name,
                  N_nodes = 1000,
                  p_neg = 0.01,
                  N_measured = 55,
                  N_stimulated = 7,
                  N_inhibited = 6,
                  cross_talk_ratio = 0.5),
    envir = parent.frame()
)


# Model 4 -----------------------------------

model_name = "insilcio model v1 N3k M50"

rmarkdown::render(
    here('benchmark/RMD_temlate_report_insilico_model.Rmd'),
    output_file = here(file.path("benchmark",paste0(gsub(" ","_",model_name), '.html'))),
    params = list(rnd_seed = 1987,
                  model_name = model_name,
                  N_nodes = 3000,
                  p_neg = 0.01,
                  N_measured = 50,
                  N_stimulated = 7,
                  N_inhibited = 6,
                  cross_talk_ratio = 0.5),
    envir = parent.frame()
)

