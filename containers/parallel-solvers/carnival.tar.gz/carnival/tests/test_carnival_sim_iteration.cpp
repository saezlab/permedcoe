#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <time.h>
#include <stdexcept>
#include "vector_funcs.hpp"
#include "carnival_data.hpp"
#include "compute_score_t1_carnival.hpp"

using std::cout;
using std::endl;

int printDiagnostics = 0;



template <typename T>
std::vector<std::vector<T>> read_csv(const std::string& input, char separator=',') {
    std::fstream fin;
    fin.open(input);

    std::vector<std::vector<T>> output;

    if (fin.is_open()) {
        std::string temp;
        while (std::getline(fin, temp)) {
            std::vector<T> row;
            std::string token;
            std::istringstream ss(temp);
            while (std::getline(ss, token, separator)) {
                row.push_back(static_cast<T>(stod(token)));
            }
            output.push_back(row);
        }
        fin.close();
    }
    return output;
}

int main(int argc, char **argv) {

    
    if (argc < 3) throw std::runtime_error("Need 3 input files(.h5 model description and .csv bitstrings");

    // Read in the data
    auto d = Carnival_data(std::string(argv[1]));
    auto bitstrings = read_csv<int>(argv[2]);

    int simulation_max_iter = 100; 

    clock_t begin;
    clock_t end;
    double time_spent;


    if(printDiagnostics==1){
        std::cout << "max iter: " << simulation_max_iter << std::endl;
        std::cout << "string \t iterations \t time[ms] \t score" << std::endl;
    }
    
    // Calculate the scores using compute_score_t1 function
    std::vector<double> scores;
    int i = 0;
    for (auto& bs : bitstrings) {
    
        if(printDiagnostics==1){
            std::cout << i+1 << "\t";    
            std::cout << bs << std::endl;
            begin = clock();
        }
        
        scores.push_back(compute_score_t1_carnival(d, bs, simulation_max_iter)); 

        
        if(printDiagnostics == 1){
            end = clock();
            time_spent = (double)(end - begin) / (CLOCKS_PER_SEC/1000);
            std::cout << time_spent << "\t" << scores[i] << std::endl;
        }
        
        ++i;
    }
    
    std::cout << "Scores: \t" << scores;
    
    return(0);
    
}

