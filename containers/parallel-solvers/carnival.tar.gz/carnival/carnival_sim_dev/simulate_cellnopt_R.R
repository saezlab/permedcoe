

# The following series of functions are not part of cellnopt package, these 
# are written for the support of the R simulator. 



cellnopt_simulateTN <- function (CNOlist, model, bStrings) 
{
	if (is.list(bStrings) == FALSE) {
		stop("CellNOpt Error: 3rd argument called bStrings must be a list of vectors. Each vector representing a bit string")
	}
	if (length(bStrings) == 1) {
		simPrev = cellnopt_internal_simulateT1(CNOlist, model, bStrings[[1]])
	}
	else if (length(bStrings) > 1) {
		simPrev = cellnopt_internal_simulateT1(CNOlist, model, bStrings[[1]])
		for (i in 2:length(bStrings)) {
			res = buildBitString(bStrings[1:i])
			simPrev = internal_simulateTN(CNOlist, model, simPrev, 
										  res$bs, res$bsTimes, i + 1)
		}
	}
	return(simPrev)
}

cellnopt_internal_simulateT1 <- function (CNOlist, model, bStringT1, simList = NULL, indexList = NULL) 
{
	modelCut <- cutModel(model, bStringT1)
	if (is.null(simList) == TRUE) {
		simList = prep4sim(model)
	}
	if (is.null(indexList) == TRUE) {
		indexList = indexFinder(CNOlist, model)
	}
	newSimList = cutSimList(simList, bStringT1)
	simRes <- cellnopt_simulatorT1(CNOlist = CNOlist, model = modelCut, 
								   simList = newSimList, indexList = indexList)
	return(simRes)
}

cellnopt_simulatorT1 <- function (CNOlist, model, simList, indexList, mode = 1) 
{
	simRes = cellnopt_cSimulator(CNOlist, model, simList, indexList, 
								 mode = mode)
	return(simRes)
}


cellnopt_cSimulator_future <- function(CNOlist, model, simList, indexList, 
									   mode = mode){
	
	
	nStimuli <- as.integer(length(indexList$stimulated))
	nInhibitors <- as.integer(length(indexList$inhibited))
	nCond <- as.integer(dim(CNOlist@stimuli)[1])
	nReacs <- as.integer(length(model$reacID))
	nSpecies <- as.integer(length(model$namesSpecies))
	nMaxInputs <- as.integer(dim(simList$finalCube)[2])
	finalCube = as.integer(simList$finalCube - 1)
	ixNeg = as.integer(simList$ixNeg)
	ignoreCube = as.integer(simList$ignoreCube)
	maxIx = as.integer(simList$maxIx - 1)
	indexSignals <- as.integer(indexList$signals - 1)
	indexStimuli <- as.integer(indexList$stimulated - 1)
	indexInhibitors <- as.integer(indexList$inhibited - 1)
	nSignals <- length(indexSignals)
	valueInhibitors <- as.integer(CNOlist@inhibitors)
	valueStimuli <- as.integer(CNOlist@stimuli)
	res = .Call("simulator_carnival", nStimuli, nInhibitors, nCond, 
				nReacs, nSpecies, nSignals, nMaxInputs, finalCube, ixNeg, 
				ignoreCube, maxIx, indexSignals, indexStimuli, indexInhibitors, 
				valueInhibitors, valueStimuli, as.integer(mode))
	
}

cellnopt_cSimulator <- function(CNOlist, model, simList, indexList, 
								mode = mode){
	
	
	nStimuli <- as.integer(length(indexList$stimulated))
	nInhibitors <- as.integer(length(indexList$inhibited))
	nCond <- as.integer(dim(CNOlist@stimuli)[1])
	nReacs <- as.integer(length(model$reacID))
	nSpecies <- as.integer(length(model$namesSpecies))
	nMaxInputs <- as.integer(dim(simList$finalCube)[2])
	finalCube = as.integer(simList$finalCube)
	ixNeg = as.integer(simList$ixNeg)
	ignoreCube = as.integer(simList$ignoreCube)
	maxIx = as.integer(simList$maxIx)
	indexSignals <- as.integer(indexList$signals)
	indexStimuli <- as.integer(indexList$stimulated )
	indexInhibitors <- as.integer(indexList$inhibited)
	nSignals <- length(indexSignals)
	valueInhibitors <- as.integer(CNOlist@inhibitors)
	valueStimuli <- as.integer(CNOlist@stimuli)
	
	res = simulator_cellnopt(nStimuli, nInhibitors, nCond, 
							 nReacs, nSpecies, nSignals, nMaxInputs, finalCube, ixNeg, 
							 ignoreCube, maxIx, indexSignals, indexStimuli, indexInhibitors, 
							 valueInhibitors, valueStimuli, as.integer(mode))
	
}





simulator_cellnopt <- function (
	
	nStimuli_in,
	nInhibitors_in,
	nCond_in,
	nReacs_in,
	nSpecies_in,
	nSignals_in,
	nMaxInputs_in,
	
	finalCube_in,
	ixNeg_in,
	ignoreCube_in,
	maxIx_in,
	
	indexSignals_in,
	indexStimuli_in,
	indexInhibitors_in,
	
	valueInhibitors_in,
	valueStimuli_in,
	mode_in
) {
	
	
	simResults = NULL;
	
	counter = 0;
	i = 0;
	j = 0;
	s = 0;
	a = 0
	b = 0
	p = 0;
	curr_max = 0;
	or_max = 0;
	
	selCounter = 0;
	# double *rans;
	
	count_na_1 = 0;
	count_na_2 = 0;
	
	#/* variables */
	nStimuli = as.integer(nStimuli_in);
	nInhibitors = as.integer(nInhibitors_in);
	nCond = as.integer(nCond_in);
	nReacs = as.integer(nReacs_in);
	nSpecies = as.integer(nSpecies_in);
	nSignals = as.integer(nSignals_in);
	nMaxInputs = as.integer(nMaxInputs_in);
	mode = as.integer(mode_in);
	
	count_species = 0;
	
	
	
	#/* see stop conditions */
	test_val = 1e-3;
	
	track_cond = 0; #/* track condition */
	track_reac = 0; #/* track reaction */
	
	current_min = 0;
	dial_reac = 0;
	dial_cond = 0;
	
	term_check_1 = 1;
	term_check_2 = 1;
	count = 1;
	diff;
	
	#//Rprintf("CellNOpt simulator T1\n");
	
	
	#int *selection;
	selection = c();
	for (i  in  1:nReacs) {
		selection[i] = 0;
	}
	
	
	
	counter = 1;
	
	maxIx = c()
	for (i in 1:nReacs) {
		maxIx[i] = as.integer(maxIx_in)[counter]
		counter = counter + 1
	}
	
	counter = 1;
	
	indexStimuli = c()
	for (i in 1:nStimuli) {
		indexStimuli[i] = as.integer(indexStimuli_in)[counter]
		counter = counter + 1
	}
	
	counter = 1;
	
	indexInhibitors = c()
	for (i in 1:nInhibitors) {
		indexInhibitors[i] = as.integer(indexInhibitors_in)[counter]
		counter = counter + 1
	}
	
	counter = 1;
	
	indexSignals  = c()
	for (i  in 1:nSignals) {
		indexSignals[i] = as.integer(indexSignals_in)[counter] 
		counter = counter + 1
	}
	
	
	# int **finalCube;
	finalCube = matrix(data = 0,nrow = nReacs, ncol = nMaxInputs)
	
	for (i in 1:nReacs) {
		for (j in 1:nMaxInputs) {
			finalCube[i,j] = as.integer(finalCube_in)[(j-1) * nReacs + i];
		}
	}
	
	# counter = 0;
	
	ixNeg = matrix(data = 0,nrow = nReacs, ncol = nMaxInputs)
	
	for (i in 1:nReacs) {
		for (j in 1:nMaxInputs) {
			ixNeg[i,j] = as.integer(ixNeg_in)[(j-1) * nReacs + i];
		}
	}
	
	# counter = 0;
	
	ignoreCube = matrix(data = 0,nrow = nReacs, ncol = nMaxInputs)
	
	for (i in 1:nReacs) {
		for (j in 1:nMaxInputs) {
			ignoreCube[i,j] = as.integer(ignoreCube_in)[(j-1) * nReacs + i];
		}
	}
	
	# counter = 0;
	valueInhibitors = matrix(data = 0,nrow = nCond, ncol = nInhibitors)
	
	if (mode == 0) {
		for (i in 1:nCond) {
			for (j in seq_len(nInhibitors)) {
				valueInhibitors[i,j] = 1;
			}
		}
	}
	else {
		
		for (i in seq_len(nCond)) {
			for (j in seq_len(nInhibitors)) {
				valueInhibitors[i,j] = as.integer(valueInhibitors_in)[nCond * (j-1) + i];
			}
		}
	}
	
	counter = 0;
	valueStimuli = matrix(data = 0,nrow = nCond, ncol = nStimuli)
	
	if (mode == 0) {
		for (i in 1:nCond) {
			for (j in seq_len(nStimuli)) {
				valueStimuli[i,j] = 0;
			}
		}
	}
	else {
		
		for (i in 1:nCond) {
			for (j in seq_len(nStimuli)) {
				valueStimuli[i,j] = as.integer(valueStimuli_in)[nCond * (j-1) + i];
			}
		}
	}
	
	
	
	
	#// fill end_ix - how many reactions have each species as input
	end_ix = rep(NA,nSpecies);
	count_species = 0;
	for (i in 1:nSpecies) {
		for (j in 1:nReacs) {
			if (i == maxIx[j]) {
				count_species = count_species+1;
			}
		}
		end_ix[i] = count_species;
		count_species = 0;
	}
	
	#/* see stop conditions */
	test_val = 1e-3;
	
	#/* create an initial values matrix*/
	init_values = matrix(NA,nrow = nCond,ncol = nSpecies);
	for (i in 1:nCond) {
		for (j in 1:nSpecies) {
			init_values[i,j] = NA;
		}
	}
	
	# /* set the initial values of the stimuli*/
	for (i in 1:nCond) {
		for (j in 1:nStimuli) {
			init_values[i,indexStimuli[j]] = valueStimuli[i,j];
		}
	}
	
	#/* flip and redefine inhibitors*/
	if (nInhibitors>0) {
		for (i in 1:nCond) {
			for (j in 1:nInhibitors) {
				valueInhibitors[i,j] = 1 - valueInhibitors[i,j];
				if (valueInhibitors[i,j] == 1) {
					valueInhibitors[i,j] = NA;
				}
			}
		}
	}
	
	# /* set the initial values of the inhibitors */
	for (i in 1:nCond) {
		for (j in seq_len(nInhibitors)) {
			init_values[i,indexInhibitors[j]] = valueInhibitors[i,j];
		}
	}
	
	#/* initialize main loop */
	output_prev = matrix(data = 0,nrow = nCond, ncol = nSpecies)
	new_input = matrix(data = 0,nrow = nCond, ncol = nSpecies)
	MA = matrix(data = 0,nrow = nCond, ncol = nSpecies)
	
	
	N_MA = max(3,floor(0.1 * nSpecies))
	
	for (i in 1:nCond) {
		for (j in 1:nSpecies) {
			new_input[i,j] = init_values[i,j];
			MA[i,j] = 0.5;
		}
	}
	
	term_check_1 = 1;
	term_check_2 = 1;
	count = 1;
	
	temp_store = matrix(data = 0,nrow = nCond * nReacs, ncol = nMaxInputs)
	rownames(temp_store) = paste0(rep(paste0("c",1:nCond),nReacs),rep(paste0("r",1:nReacs),each=nCond))
	
	# browser()
	
	#/* start simulation loop */
	while (term_check_1 && term_check_2) {
		
		#/* copy to outputPrev */
		#	/*        memcpy(output_prev, new_input, sizeof(output_prev));*/
		for (i in 1:nCond) {
			for (j in 1:nSpecies) {
				output_prev[i,j] = new_input[i,j];
			}
		}
	#	colnames(output_prev) = c("EGF", "TNFa", "Jnk", "PI3K", "Raf", "Akt", "Mek", "Erk", "NFkB", "cJun", "Hsp27", "p90RSK")
		#/* fill temp store
		#this is different to R version, through a single loop
		#with conditions */
		track_cond = 0+1; #/* track condition */
		track_reac = 0+1; #/* track reaction */
		
		
		for (i in 1:(nCond * nReacs)) {
			for (j in 1:nMaxInputs) {
				
				#/* initial values of each input */
				temp_store[i,j] = output_prev[track_cond,finalCube[track_reac,j]];
				
				if (ignoreCube[track_reac,j]) {
					temp_store[i,j] = NA;
				}
				if (ixNeg[track_reac,j] & !is.na(temp_store[i,j])) {
					#/* flip the values of the neg inputs */
					if (temp_store[i,j] == 0) {temp_store[i,j] = 1;}
					else if (temp_store[i,j] == 1) {temp_store[i,j] = 0;}
				}
				
			}
			
			track_cond = track_cond +1 
			if (track_cond == nCond+1) {
				track_cond = 0+1;
				track_reac = track_reac+1
			}
		}
		temp_store_mat = matrix(temp_store,nCond,nReacs)
		colnames(temp_store_mat) = paste0("R",1:nReacs)
		rownames(temp_store_mat) = paste0("C",1:nCond)
		
		
		#/* compute the AND gates (find the min 0/1 of each row) */
		output_cube = matrix(data = 0,nrow = nCond, ncol = nReacs)
		#browser()
		dial_reac = 0+1;
		dial_cond = 0+1;
		for (i in 1:(nCond * nReacs)) {
			current_min = temp_store[i,1];
			for (j in seq_len(nMaxInputs)) {
				# /* if statement below is for AND gates with any NA (2) input
				# in this case output should always be NA */
				if (is.na(temp_store[i,j]) && ignoreCube[dial_reac,j] == 0) {
					current_min = NA;
					break;
				}else if (!is.na(temp_store[i,j]) && temp_store[i,j] < current_min) {
					current_min = temp_store[i,j];
				}
			}
			
			output_cube[dial_cond,dial_reac] = current_min;
			dial_cond=dial_cond+1;
			if (dial_cond == nCond+1) {
				dial_cond = 1
				dial_reac = dial_reac+1
			}
		}
		
		# /* compute the OR gates and reinitialize new_input */
		for (i in 1:nCond) {
			for (j in 1:nSpecies) {
				new_input[i,j] = NA;
			}
		}
		
		#/* declare vector to store 'selection' (R) */
		selCounter = 0;
		for (s in 1:nSpecies) {
			#/* is the species an output for any reactions?*/
			if (end_ix[s]) {
				
				#/* find reactions with this species as output
				#add equivalent output_cube data to new_input*/
				
				for (a in 1:nReacs) {
					if (s == maxIx[a]) {
						selection[selCounter+1] = a; selCounter=selCounter+1}
				}
				# // Rprintf("checkpoint 4\n");
				#/* if the species is an output for a single reaction
				# it's a 1-1 mapping to new_input */
				if (selCounter == 1) {
					for (b in 1:nCond) {
						
						new_input[b,s] = output_cube[b,selection[selCounter]];  # do we need the -1? 
					}
					selCounter = 0;
				}
				#/* else if species is output for > 1 reactions */
				if (selCounter > 1) {
					for (i in 1:nCond) {
						or_max = NA;
						curr_max = 0;
						for (p in seq_len(selCounter)) {
							if (!is.na(output_cube[i,selection[p]]) && output_cube[i,selection[p]] >= curr_max) {
								or_max = output_cube[i,selection[p]];
								curr_max = output_cube[i,selection[p]];
							}
						}
						new_input[i,s] = or_max;
					}
					selCounter = 0;
				}
			}
		}
		
		#/* reset the stimuli */
		for (i in seq_len(nCond)) {
			for (j in seq_len(nStimuli)) {
				curr_max = valueStimuli[i,j];
				if (new_input[i,indexStimuli[j]] > curr_max && !is.na(new_input[i,indexStimuli[j]])) {
					curr_max = new_input[i,indexStimuli[j]];
				}
				new_input[i,indexStimuli[j]] = curr_max;
			}
		}
		#browser()
		#/* reset the inhibitors */
		for (i in seq_len(nCond)) {
			for (j in seq_len(nInhibitors)) {
				if (mode == 1) {
					if (!is.na(valueInhibitors[i,j]) && valueInhibitors[i,j] == 0) {
						new_input[i,indexInhibitors[j]] = 0;
					}
				}
				else {
					
					# /* BUG FIX Sept 2014, TC*/
					# /* at time0, inhibitors are all off by default. So, we do
					#  * not want to reset their content at each tick. There is
					#  * not need for the code above. This is especially important
					#  * if a node if both inhibted and a readout and/or there
					#  * are input links that are inhibitors*/
				}
			}
		}
		
		
		count_na_1 = 0;
		count_na_2 = 0;
		#/* set 'NAs' (2s) to 0 */
		for (i in seq_len(nCond)) {
			for (j in 1:nSpecies) {
				if (is.na(new_input[i,j])) {
					count_na_1=count_na_1+1 ;
					new_input[i,j] = 0;
				}
				if (is.na(output_prev[i,j])) {
					count_na_2=count_na_2+1 ;
					output_prev[i,j] = 0;
				}
			}
		}
		
		
		term_check_1 = 0;
		for (i in 1:nCond) {
			for (j in 1:nSpecies) {
				diff = abs((new_input[i,j] - output_prev[i,j]));
				if (diff > test_val) {
					term_check_1 = 1;
					break;  #/*  no need to keep going checking other values if
					#   one is greater than test_val */
				}
			}
			#//            printf("\n");
		}
		if (count_na_1 != count_na_2) {
			term_check_1 = 1;
		}
		if (count == nSpecies) {
			#           /* initialise moving average for each state
			#          By interation nSpecies +1 all states are updated at least once, and steady states are achieved. 
			#         */
			for (i in 1:nCond) {
				for (j in 1:nSpecies) {
					MA[i,j] = new_input[i,j];
				}
			}
			
		}
		if (count > nSpecies) {
			#// compute moving average for each state in each condition
			for (i in 1:nCond) {
				for (j in 1:nSpecies) {
					MA[i,j] = MA[i,j] * (N_MA - 1) / N_MA + (new_input[i,j]) / N_MA;
				}
			}
			#//Rprintf("l 460\n");
			#//RprintMA(&MA[0][0], nCond, nSpecies);
		}
		#/*term_check_1 = !(abs(diff) < test_val);*/
		term_check_2 = (count < (nSpecies * 1.2));
		count = count+1;
		
	}
	#//Rprintf("end of while:\n");
	#//RprintStatus(&new_input[0][0], nCond, nSpecies);
	
	
	#/* set non-resolved bits to 2 (NA)*/
	for (i in 1:nCond) {
		for (j in 1:nSpecies) {
			if (new_input[i,j] != output_prev[i,j])
				new_input[i,j] = NA;
		}
	}
	#//Rprintf("set non-resolved bits to 2 (NA):\n");
	#//RprintStatus(&new_input[0][0], nCond, nSpecies);
	
	# /* set oscillating bits to 2 (NA)*/
	if(count > nSpecies+1){
		for (i in 1:nCond) {
			for (j in 1:nSpecies) {
				if (MA[i,j]<0.95 & MA[i,j]>0.05)  #// actually we could check if they are exactly 0 or 1
					new_input[i,j] = NA;
			}
		}
	}
	# //Rprintf("l 489\n");
	# //RprintMA(&MA[0][0], nCond, nSpecies);
	# //Rprintf("set oscillating bits to 2 (NA):\n");
	# //RprintStatus(&new_input[0][0], nCond, nSpecies);
	
	simResults = matrix(data = 0,nrow = nCond, ncol = nSpecies) 
	rans = c()
	for (i in 1:nCond) {
		for (j in 1:nSpecies) {
			if (is.na(new_input[i,j])) {
				simResults[i + nCond * (j-1)] = NA;
			} else simResults[i + nCond * (j-1)] = new_input[i,j];
		}
	}
	
	# /* this code works but raise issue when calling simulatorT1 */
	# /*     PROTECT(simResults = allocMatrix(REALSXP, nCond, nSignals));
	#     rans = c();
	#     for(i in 1:nCond) {
	#         for(j in 1:nSignals) {
	#             if(is.na(new_input[i][indexSignals[j]])){
	#             	rans[i + nCond*(j-1)] = NA
	#             	} else rans[i + nCond*(j-1)] = new_input[i][indexSignals[j]];
	#         }
	#     }
	# */
	
	
	# free(maxIx);
	# // Rprintf("checkpoint 6\n");
	# free(selection);
	# // Rprintf("checkpoint 7\n");
	# free(indexStimuli);
	# free(indexInhibitors);
	# free(indexSignals);
	
	# for (i = 0; i < nReacs; i++) {
	#     free(finalCube[i]);
	# }
	# free(finalCube);
	# 
	# for (i = 0; i < nReacs; i++) {
	#     free(ixNeg[i]);
	# }
	# free(ixNeg);
	# 
	# for (i = 0; i < nReacs; i++) {
	#     free(ignoreCube[i]);
	# }
	# free(ignoreCube);
	# 
	# for (i = 0; i < nCond; i++) {
	#     free(valueInhibitors[i]);
	# }
	# free(valueInhibitors);
	# 
	# for (i = 0; i < nCond; i++) {
	#     free(valueStimuli[i]);
	# }
	# free(valueStimuli);
	# 
	# UNPROTECT(1);
	return (simResults)
	
}


