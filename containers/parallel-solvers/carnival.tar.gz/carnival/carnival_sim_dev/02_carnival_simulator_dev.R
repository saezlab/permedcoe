# by Attila Gabor
#
# 08.07.2021
# The  R-based cellnopt simulator was modified to handle 3-state system (-1, 0, 1)
# here are some lines of code to test the results. 

library(here)
library(tidyverse)
library(CellNOptR)
library(CARNIVAL)

source("simulate_carnival_R.R")
source("simulate_carnival_R_utils.R")

cplex_path = system("which cplex", intern=T)

# maps CARNIVAL output to the PKN and generates a BitString to plot with CellNOpt
carnival_to_bString <- function(model, result) {
	carnival_reactions <-
		result$weightedSIF %>% tibble::as_tibble() %>%
		dplyr::mutate(reacID = paste0(ifelse(Sign == 1, "", "!"), Node1, "=", Node2)) %>%
		pull(reacID)
	
	bString = as.numeric(model$reacID %in% carnival_reactions)
	
	if (!all(carnival_reactions %in% model$reacID))
		stop("carnival reaction not in PKN!")
	
	return(bString)
}



# Lets start with the toy, it has inhibitors, need also AND gates
# toy network --------------------------------------
data(CNOlistToy,package="CellNOptR")
data(ToyModel,package="CellNOptR")

cnodata = CNOlist(CNOlistToy)
model = ToyModel
model = preprocessing(data = cnodata,model = model,expansion = TRUE)
# no AND gate
bstring = c(1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1 ,1 ,1, 0, 0, 0)
plotModel(model,cnodata, bString = bstring)

# this is hard to compare, because the bitstring is not optimal. 
simResults_carnival = carnival_simulateTN(CNOlist=cnodata, model = model, bStrings = list(bstring))
carnival_cutAndPlot(CNOlist = cnodata,model = model,bStrings = list(bstring))



### Toy model with CelNOpt optimization but carnival simulation ------------
data(CNOlistToy,package="CellNOptR")
data(ToyModel,package="CellNOptR")

cnodata = CNOlist(CNOlistToy)
model = ToyModel
model = preprocessing(data = cnodata,model = model,expansion = TRUE)

ga_res = gaBinaryT1(CNOlist = cnodata,model = model)

bstring = ga_res$bString
pdf("./toymodel_test.pdf")
plotModel(model,cnodata,bString = bstring)
cutAndPlot(CNOlist = cnodata,model = model,bStrings = list(bstring))
carnival_cutAndPlot(CNOlist = cnodata,model = model,bStrings = list(bstring))
dev.off()

simResults_carnival = carnival_simulateTN(CNOlist=cnodata, model = model, bStrings = list(bstring))
simResults_cellnopt = simulateTN(CNOlist=cnodata, model = model, bStrings = list(bstring))

colnames(simResults_carnival) <- model$namesSpecies
colnames(simResults_cellnopt) <- model$namesSpecies

simResults_carnival == simResults_cellnopt








# load a cellnopt case study:
# case study 1

cnodata = CNOlist(here("carnival_sim_dev/test_cases/cs1_data.csv"))
model = readSIF(here("carnival_sim_dev/test_cases/cs1_network.sif"))

plotModel(model)

input = data.frame(I1 = 1, I2 = 1)
measurement = data.frame(a = 1, c = 1, b = 0)
carnival_network = read_delim("carnival_sim_dev/test_cases/cs1_network.sif",delim = " \t",col_names = FALSE) %>%
	rename(source = X1, interaction = X2, target = X3)


res3 = runCARNIVAL(inputObj = input,
				   measObj = measurement,
				   netObj = carnival_network,
				   solver = 'cplex',betaWeight = 0,
				   solverPath = cplex_path)
plotModel(model = model,cnodata,bString = carnival_to_bString(model,res3))

simResults_carnival = carnival_simulateTN(CNOlist=cnodata, model = model, bStrings = list(rep(1,4)))
simResults_cellnopt = simulateTN(CNOlist=cnodata, model = model, bStrings = list(rep(1,4)))

simResults_carnival == simResults_cellnopt


# CS1 with AND gates -----------------------------

cnodata = CNOlist(here("carnival_sim_dev/test_cases/cs1_data.csv"))
model = readSIF(here("carnival_sim_dev/test_cases/cs1_network.sif"))
model = preprocessing(data = cnodata,model = model,expansion = TRUE)
bstring = c(1,0,0,1,1)
plotModel(model,bString = bstring)

simResults_carnival = cellnopt_simulateTN(CNOlist=cnodata, model = model, bStrings = list(bstring))
simResults_cellnopt = simulateTN(CNOlist=cnodata, model = model, bStrings = list(bstring))

simResults_carnival == simResults_cellnopt

# CS1 with all gates -----------------------------

cnodata = CNOlist(here("carnival_sim_dev/test_cases/cs1_data.csv"))
model = readSIF(here("carnival_sim_dev/test_cases/cs1_network.sif"))
model = preprocessing(data = cnodata,model = model,expansion = TRUE)
bstring = c(1,1,1,1,1)
plotModel(model,bString = bstring)

simResults_carnival = cellnopt_simulateTN(CNOlist=cnodata, model = model, bStrings = list(bstring))
simResults_cellnopt = simulateTN(CNOlist=cnodata, model = model, bStrings = list(bstring))

simResults_carnival == simResults_cellnopt




# big networtk -----------------------------------
cnodata = CNOlist(here("carnival_sim_dev/test_cases/ExtLiverBMC2012/MD-ExtLiverPCB.csv"))
model = readSIF(here("carnival_sim_dev/test_cases/ExtLiverBMC2012/PKN-ExtLiverBMC2012.sif"))

prep_model = preprocessing(data = cnodata,
						   model = model,
						   cutNONC = TRUE,
						   compression = TRUE,
						   expansion = TRUE)


sol <- c(0, 0, 1, 0, 0, 0, 1, 1, 1, 0, 0, 0, 1, 1, 1, 0, 1, 0, 0, 0, 1, 1, 0, 0, 
		 0, 0, 1, 1, 0, 0, 0, 0, 1, 0, 1, 0, 0, 1, 0, 1, 1, 1, 0, 0, 0, 1, 0, 0, 
		 1, 1, 0, 1, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
		 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
		 0, 0, 0, 0, 0, 1, 0, 0, 1, 0, 0, 0)

simResults_carnival = cellnopt_simulateTN(CNOlist=cnodata, model = prep_model, bStrings = list(sol))
simResults_cellnopt = simulateTN(CNOlist=cnodata, model = prep_model, bStrings = list(sol))

simResults_carnival == simResults_cellnopt


simResults_carnival[3,17]
simResults_cellnopt[3,17]

computeScoreTN(cnodata, prep_model,
			   bStrings = list(sol),
			   sizeFac = 0, NAFac = 10)
