

# The following series of functions are not part of cellnopt package, these 
# are written for the support of the R simulator. 

carnival_plotOptimResultsPan <- function(simResults, yInterpol=NULL, xCoords=NULL,
								CNOlist=CNOlist, formalism=c("ss1","ss2","ssN","dt","ode"), pdf=FALSE,
								pdfFileName="", tPt=NULL, plotParams=list(margin=0.1, width=15, height=12,
																		  cmap_scale=1, cex=1.6, ymin=NULL, F=1, rotation=0)) {
	
	
	if ((class(CNOlist)=="CNOlist")==FALSE){
		CNOlist = CellNOptR::CNOlist(CNOlist)
	}
	
	formalism <- match.arg(formalism)
	# index valueSignals according to tPt
	valueSignalsI = sapply(c(0,tPt), function(x) which(CNOlist@timepoints==x))
	
	if ("margin" %in% names(plotParams) == FALSE){
		plotParams$margin = 0.1
	}
	if ("cex" %in% names(plotParams) == FALSE){
		plotParams$cex = 1.6
	}
	if ("width" %in% names(plotParams) == FALSE){
		plotParams$width = 15
	}
	if ("height" %in% names(plotParams) == FALSE){
		plotParams$height = 12
	}
	if ("cmap_scale" %in% names(plotParams) == FALSE){
		plotParams$cmap_scale = 1
	}
	if ("lwd" %in% names(plotParams) == FALSE){
		plotParams$lwd = 3
	}
	if ("pch" %in% names(plotParams) == FALSE){
		plotParams$pch = 16
	}
	if ("ymin" %in% names(plotParams) == FALSE){
		plotParams$ymin = NULL
	}
	if ("F" %in% names(plotParams) == FALSE){
		plotParams$F = 1
	}
	if ("rotation" %in% names(plotParams) == FALSE){
		plotParams$rotation = 0
	}
	
	# aliases
	margin = plotParams$margin
	cex = plotParams$cex
	
	#####    functions    #####
	
	list2Array = function(x, dim) {
		xUnlist = unlist(x);
		xArray=array(xUnlist,dim=dim)
	}
	
	#####    /functions/    #####
	
	
	opar = par(no.readonly = TRUE)
	on.exit(par(opar))
	
	if(pdf==TRUE) {
		pdf(file=pdfFileName, width=plotParams$width, height=plotParams$height)
	}
	
	Ncols = dim(CNOlist@signals[[1]])[2]
	Nrows = dim(CNOlist@signals[[1]])[1]
	
	split.screen(c(1, Ncols+3))
	for(a in 1:(Ncols+2)) {
		split.screen(c(Nrows+1,1),a) # why +2 ?
	}
	
	
	# TODO - do i need all these with split.screen?
	par(
		pch=2,
		# margin bottom of pcolor mesh: oma(X,Y,W,Z) where X is distance bottom
		# to the colormesh
		oma=c(3,2,2,2),
		mgp=c(3,0.9,0),
		family="Times"
	)
	
	Ncolors = 1000
	
	heatCols = heat.colors(Ncolors)
	
	# maximum across all data points
	#yMax <- max(unlist(lapply(CNOlist$valueSignals, function(x) max(x,na.rm=TRUE))))
	yMax=1
	# minimum across all data points
	
	if (is.null(plotParams$ymin)==FALSE){
		yMin = plotParams$ymin
	} else {
		yMin <- min(unlist(lapply(CNOlist@signals, function(x) min(x,na.rm=TRUE))))
	}
	yMin = -1
	
	# time labels
	xVal <- CNOlist@timepoints[valueSignalsI]
	if(formalism=="dt") {
		xValS = xCoords
		norm = length(CNOlist@timepoints)
	} else if (formalism == "ss1") {
		xValS = c(0,tPt[1])
		norm = 2
	} else if (formalism == "ss2") {
		xValS = c(0,tPt[1:2])
		norm = 3
	} else if (formalism == "ssN") {
		xValS = c(0,tPt)
		norm = length(tPt)+1 # should be number of time points.
	} else if (formalism == "ode") {
		xValS = CNOlist@timepoints
		xVal <- CNOlist@timepoints
		valueSignalsI = seq(1, length(xValS))
		norm = length(CNOlist@timepoints)
	}else {
		xValS = xVal
	}
	# latest time point
	xValMax = max(xVal)
	
	# make simResults array if not already
	
	if(!is.array(simResults)) {
		simResults = list2Array(simResults, dim=c(dim(simResults[[1]]),length(simResults)))
	}
	
	# make valueSignals an array
	valueSignalsArr = list2Array(CNOlist@signals,
								 dim=c(dim(CNOlist@signals[[1]]),length(CNOlist@signals)))
	
	# calculate the MSE
	allDiff = matrix(NA, nrow=dim(simResults)[1], ncol=dim(simResults)[2])
	
	if(formalism != "dt") {
		# ss1, ss2, ssN
		for(a in 1:dim(simResults)[1]) {
			for(b in 1:dim(simResults)[2]) {
				c1 = simResults[a,b,]
				c2 = valueSignalsArr[a,b,valueSignalsI]
				NAcount = max(sum(is.na(c1)), sum(is.na(c2)))
				allDiff[a,b] = sum((c1 - c2)^2, na.rm=TRUE)/(norm - NAcount)
			}
		}
	} else {
		# dt
		for(a in 1:dim(simResults)[1]) {
			for(b in 1:dim(simResults)[2]) {
				c1 =  simResults[a,b,]
				c2 = yInterpol[a,b,]
				NAcount = max(sum(is.na(c1)), sum(is.na(c2)))
				allDiff[a,b] = sum((c1 - c2)^2, na.rm=TRUE)/(norm - NAcount)
			}
		}
	}
	# max difference between sim and exper
	#diffMax = max(unlist(!is.na(allDiff)))
	
	# set the count for the split screen window
	count1 = dim(CNOlist@signals[[1]])[2]+4
	
	# plot headers
	for(c in 1:dim(CNOlist@signals[[1]])[2]) {
		screen(count1)
		par(fg="blue",mar=c(margin, margin, margin, 0))
		plot(x=xVal, y=rep(-5,length(xVal)), ylim=c(yMin, yMax),
			 xlab=NA,ylab=NA,xaxt="n",yaxt="n")
		labels=colnames(CNOlist@signals[[1]])[c]
		text(
			labels=labels,
			x=((xVal[length(xVal)]-xVal[1])/2),
			y=(yMin+((yMax-yMin)/2)),
			cex=cex
		)
		count1 = count1 + dim(CNOlist@signals[[1]])[1]+1
	}
	
	# stim + inhib
	screen(count1)
	par(fg="blue",mar=c(margin, margin, margin, 0))
	plot(
		x = xVal,
		y = rep(-5,length(xVal)),
		ylim = c(yMin, yMax),
		xlab = NA,ylab=NA,xaxt="n",yaxt="n"
	)
	text(
		labels = "Stim",
		x = ((xVal[length(xVal)]-xVal[1])/2),
		y = (yMin+((yMax-yMin)/2)),cex=cex
	)
	
	count1 = count1 + dim(CNOlist@signals[[1]])[1]+1
	screen(count1)
	#par(fg="blue",mar=c(0.5,0.5,0.7,0))
	par(fg="blue",mar=c(margin, margin, margin, 0))
	plot(
		x = xVal, y=rep(-5,length(xVal)),
		ylim = c(yMin, yMax),
		xlab = NA,ylab=NA,xaxt="n",yaxt="n")
	text(
		labels="Inh",
		x=((xVal[length(xVal)]-xVal[1])/2),
		y=(yMin+((yMax-yMin)/2)),cex=cex
	)
	
	
	# new count for plotting results
	countRow = dim(CNOlist@signals[[1]])[2]+4
	
	
	for(c in 1:dim(CNOlist@signals[[1]])[2]) {
		countRow=countRow+1
		for(r in 1:dim(CNOlist@signals[[1]])[1]) {
			
			screen(countRow)
			par(fg="black",mar=c(margin, margin,0,0))
			yVal <- lapply(CNOlist@signals[valueSignalsI], function(x) {x[r,c]})
			
			yValS <- simResults[r,c,]
			if(!is.na(allDiff[r,c])) {
				#diff = (1 - (allDiff[r,c] / diffMax)) * 1000
				diff = (1 - (allDiff[r,c] /plotParams$F)**plotParams$cmap_scale) * (Ncolors-1)+1
			} else {
				diff = -1
			}
			if (diff <1 & diff!=-1){diff=1}
			
			if(diff>Ncolors) {
				diff=Ncolors
			}
			# this is a NA or NaN so what color ?
			if(diff==-1) {
				bgcolor = "gray"
			} else{
				bgcolor = heatCols[diff]
			}
			plot(x=xVal,y=yVal,ylim=c(yMin,yMax),xlab=NA,ylab=NA,xaxt="n",yaxt="n",)
			rect(par("usr")[1], par("usr")[3], par("usr")[2], par("usr")[4], col=bgcolor)
			
			
			tryCatch(
				{ystd = unlist(lapply(CNOlist@variances[valueSignalsI],function(x) {x[r,c]}))
				.error.bar(unlist(xVal), unlist(yVal), ystd)
				}, error=function(e){}
			)
			
			
			
			
			# the measurements
			lines(xVal, yVal, ylim=c(yMin, yMax), xlab=NA, ylab=NA, xaxt="n", yaxt="n", col="black", lty=1, lwd=1)
			points(x=xVal,y=yVal,ylim=c(yMin, yMax),xlab=NA,ylab=NA,xaxt="n",yaxt="n",pch=2)
			
			# the simulated data
			lines(xValS, yValS, xlim=c(0,xValMax), ylim=c(yMin, yMax),
				  xlab=NA, ylab=NA, xaxt="n", yaxt="n", col="blue", lty=2, lwd=plotParams$lwd)
			points(xValS, yValS, xlim=c(0,xValMax), ylim=c(yMin, yMax),
				   xlab=NA, ylab=NA, xaxt="n", yaxt="n", col="blue", pch=plotParams$pch)
			
			# add the axis annotations: if we're on the last row, add the x axis
			if(r == dim(CNOlist@signals[[1]])[1]) {
				axis(side=1,at=CNOlist@timepoints)
			}
			
			# add the axis annotations: if we're on the first column, add the y axis
			if(c == 1)    {
				axis(side=2,at=c(0,0.5,1), labels=c("","0.5",""), las=1)
			}
			
			countRow=countRow+1
		}
	}
	
	sStim = countRow+1
	
	for(c1 in 1:dim(CNOlist@signals[[1]])[1]) {
		screen(sStim)
		#par(mar=c(0.5,0.5,0.5,0.5))
		par(mar=c(margin, margin,0,0))
		
		
		data = matrix(CNOlist@stimuli[c1,],nrow=1)
		if(c1 == dim(CNOlist@signals[[1]])[1]){
			barplot(data,yaxt="n",ylim=c(0,1),names.arg = colnames(CNOlist@stimuli),las=2)
			#axis(1)
		}else{
			barplot(data,xaxt="n",yaxt="n",ylim=c(0,1))
			#axis(1)
		}
		
		
		sStim = sStim+1
	}
	
	sInhib = sStim+1
	for(c1 in 1:dim(CNOlist@signals[[1]])[1]) {
		screen(sInhib)
		
		#par(mar=c(0.5,0.5,0.5,0.5))
		par(mar=c(margin, margin,0,0))
		
		if (length(CNOlist@inhibitors) != 0){
			data = matrix(c(CNOlist@inhibitors[c1,]),nrow=1)
			if(c1 == dim(CNOlist@signals[[1]])[1]){
				barplot(data,yaxt="n",ylim=c(0,1),names.arg = c(paste(colnames(CNOlist@inhibitors),"-i",sep="")),las=3 )
				#axis(1)
			}else{
				barplot(data,xaxt="n",yaxt="n",ylim=c(0,1))
				#axis(1)
			}
		}
		else{ # special case of no inhibitors
			image(
				t(matrix(0,nrow=1)),
				col=c("grey"),xaxt="n",yaxt="n"
			)
		}
		
		
		sInhib = sInhib+1
	}
	
	screen(dim(CNOlist@signals[[1]])[2]+3)
	splitProp = 1/(dim(CNOlist@signals[[1]])[1]+1)
	sSplit = matrix(c(0,1,(1-splitProp),1,0,1,0,(1-splitProp)),ncol=4, byrow=TRUE)
	split.screen(sSplit)
	screen(sInhib)
	#       par(fg="blue",mar=c(0.5,0.5,0.7,0))
	par(fg="blue",mar=c(margin, margin, margin, 0))
	plot(
		x = xVal,
		y = rep(-5,length(xVal)),
		ylim = c(yMin, yMax),
		xlab = NA,ylab=NA,xaxt="n",yaxt="n"
	)
	text(
		labels = "Error",
		x = ((xVal[length(xVal)]-xVal[1])/2),
		y = (yMin+((yMax-yMin)/2)),cex=cex
	)
	
	screen(sInhib+1)
	
	Ncolors = 100
	colbar = heat.colors(Ncolors)
	
	# scale the colorbar in the same way as the colors used in the boxes
	# according to diff.
	colbar = colbar[as.integer((seq(0, Ncolors,length.out=100)/Ncolors)**plotParams$cmap_scale*Ncolors)]
	
	labels = c(1,0.5,0)
	len <- length(colbar)
	rhs <- 0.5
	rhs2 <- rhs + rhs/10
	at <- c(0, 0.5, 1)
	
	par(mai=c(0,0.1,0,0))
	#plot.new()
	
	tryCatch({
		plot.new()
		yyy <- seq(0,1,length=len+1)
		rect(0, yyy[1:len], rep(rhs, len), yyy[-1], col = colbar, border = colbar)
		rect(0, 0, rhs, 1, border="black")
		segments(rhs, at, rhs2, at)
		text(x=rhs2, y=at, labels=labels, pos=4, offset=0.2)
		
	},
	error=function(e){print("could not add colorbar. Skipped")}
	)
	
	
	close.screen(all.screens=TRUE)
	#    par(oldPar)
	if(pdf==TRUE) {
		dev.off()
	}
	
	return(allDiff)
}


.error.bar <- function(x, y, upper, lower=upper, length=0.1,...){
	if(length(x) != length(y) | length(y) !=length(lower) | length(lower) !=
	   length(upper))
		stop("vectors must be same length")
	
	positives = upper > 0
	x = x[positives]
	y = y[positives]
	upper = upper[positives]
	lower = lower[positives]
	arrows(x,y+upper, x, y-lower, angle=90, code=3, length=length, ...)
}


carnival_simulatorT0<-function(CNOlist,model,simList,indexList){
	
	if ((class(CNOlist)=="CNOlist")==FALSE){
		CNOlist = CellNOptR::CNOlist(CNOlist)
	}
	
	# This simulator is dedicated to the time0 case.
	# It creates a new structure called CNOlistT0, which is a subset of a CNOlist
	# It also sets the valueInhibitors and valueStimuli to zero.
	mi = CNOlist@inhibitors
	ms = CNOlist@stimuli
	# only inhibitors and stimuli are required but need to convert this into a
	# a valid CNOlist class, so we must provide all values
	
	CNOlistT0 = CNOlist
	CNOlistT0@inhibitors = matrix(1, dim(mi)[1], dim(mi)[2])
	CNOlistT0@stimuli    = matrix(0, dim(ms)[1], dim(ms)[2])
	
	# !! hack. SimulatorT1 expect the inhibitors values to be 0 or 1.
	# Then, it flips them. So, the 0-values are flipped to 1. finally,
	# the values that are equal to 1 are set to NA...
	# Here, since this is T0, all inhibitors are set to 0. simulatorT1 will
	# therefore flip them to 1 and finally NA. So, we set all inhibitors to 1.
	
	# Need to be very careful if simulatorT1 changes
	
	# Finally run the simulator with the particular set of experiments at t0
	newInput = carnival_simulatorT1(CNOlistT0, model, simList, indexList, mode=0)
	return(newInput)
}



carnival_cutAndPlotResultsT1 <- function(model, bString, simList=NULL, CNOlist, indexList=NULL,
										 plotPDF=FALSE, tag=NULL, tPt=CNOlist@timepoints[2], plotParams=list(maxrow=10))
{
	
	if ((class(CNOlist)=="CNOlist")==FALSE){
		CNOlist = CellNOptR::CNOlist(CNOlist)
	}
	if (is.null(simList)==TRUE){
		simList = prep4sim(model)
	}
	if (is.null(indexList)==TRUE){
		indexList = indexFinder(CNOlist, model)
	}
	
	if ("maxrow" %in% names(plotParams) == FALSE){
		plotParams$maxrow = 10
	}
	
	
	# keep simList and indxList for back compatibility ?
	modelCut <- cutModel(model, bString)
	simListCut <- cutSimList(simList, bString)
	# t0
	Sim0 <- carnival_simulatorT0(CNOlist=CNOlist, model=modelCut, simList=simListCut, indexList=indexList)
	simRes0 <- as.matrix(Sim0[,indexList$signals,drop=FALSE])
	#simRes0 = Sim0
	# t1
	Sim <- carnival_simulatorT1(CNOlist=CNOlist, model=modelCut, simList=simListCut, indexList=indexList)
	simRes <- as.matrix(Sim[,indexList$signals,drop=FALSE])
	#simRes = Sim
	
	simResults <- list(t0=simRes0, t1=simRes)
	
	# if there is a lot of data, split up cnolist
	# make the max dimensions 10 x 10
	
	dim1 = dim(CNOlist@signals[[1]])[1]
	dim2 = dim(CNOlist@signals[[1]])[2]
	
	CNOlistSet = list()
	simResultsSet = list()
	
	if(dim1 > plotParams$maxrow) { #|| dim2 > 10) {
		
		par1 = ceiling(dim1/plotParams$maxrow)
		div1 = ceiling(dim1/par1)
		#par2 = ceiling(dim2/plotParams$maxrow)
		#div2 = ceiling(dim2/par2)
		
		count1 = 1
		for(a in 1:par1) {
			CNOdiv = CNOlist
			simDiv = simResults
			finalN = div1 * a
			if(finalN > dim1) {finalN = dim1}
			CNOdiv@cues = CNOdiv@cues[count1:finalN,,drop=FALSE]
			CNOdiv@stimuli = CNOdiv@stimuli[count1:finalN,,drop=FALSE]
			CNOdiv@inhibitors = CNOdiv@inhibitors[count1:finalN,,drop=FALSE]
			for(b in 1:length(CNOdiv@signals)) {
				CNOdiv@signals[[b]] = CNOdiv@signals[[b]][count1:finalN,,drop=FALSE]
			}
			for(d in 1:length(simDiv)) {
				simDiv[[d]] = simDiv[[d]][count1:finalN,,drop=FALSE]
			}
			count1 = count1 + div1
			CNOlistSet = c(CNOlistSet, list(CNOdiv))
			simResultsSet = c(simResultsSet, list(simDiv))
		}
	} else {
		
		CNOlistSet = list(CNOlist)
		simResultsSet = list(simResults)
	}
	
	outputFilenames = list()
	for(f in 1:length(CNOlistSet)) {
		
		mse = carnival_plotOptimResultsPan(
			simResults=simResultsSet[[f]],
			CNOlist=CNOlistSet[[f]],
			formalism="ss1",
			tPt=tPt,
			plotParams=plotParams
		)
		
		if(plotPDF == TRUE) {
			if(is.null(tag)) {
				filename <- paste("SimResultsT1_", f, ".pdf", sep="")
			} else {
				filename <- paste(tag,"SimResultsT1",f,".pdf",sep="_")
			}
			mse = carnival_plotOptimResultsPan(
				simResults=simResultsSet[[f]],
				CNOlist=CNOlistSet[[f]],
				pdf=TRUE,
				formalism="ss1",
				pdfFileName=filename,
				tPt=tPt,
				plotParams=plotParams
			)
			outputFilenames[[f]] = filename
		}
	}
	return(list(filenames=outputFilenames, mse=mse, simResults=simResultsSet))
}


carnival_cutAndPlot <- function(CNOlist, model, bStrings, plotPDF=FALSE, tag=NULL,
								plotParams=list(maxrow=10))
{
	
	
	if ((class(CNOlist)=="CNOlist")==FALSE){
		CNOlist = CellNOptR::CNOlist(CNOlist)
	} 
	
	
	
	# bitStrings must be a list of bitString (T1, T2, ...TN)
	tPt = length(bStrings)+1
	
	simList <- prep4sim(model)
	indexList <- indexFinder(CNOlist=CNOlist,model=model)
	
	
	
	# if tPt nothing to plot
	if (tPt==1){
		stop("noting to do with time data at time 0")
	}
	
	# if tPt=2 (default), call cutAndPlotResultsT1
	if (tPt == 2){
		#print("Entering cutAndPlotResultsT1")
		
		outputs = carnival_cutAndPlotResultsT1(model=model, bString=bStrings[[1]], simList=simList, 
											   CNOlist=CNOlist, indexList=indexList, plotPDF=plotPDF, tag=tag,
											   plotParams=plotParams)
	}
	
	if (tPt>=3){
		#print("Entering cutAndPlotResultsTN")
		outputs = carnival_cutAndPlotResultsTN(
			CNOlist=CNOlist,
			model=model,
			bStrings=bStrings,
			plotPDF=plotPDF,
			tag=tag) 
	}
	# if tPt=2 (default), call cutAndPlotResultsT2
	return(outputs)
}


carnival_simulateTN <- function (CNOlist, model, bStrings) 
{
	if (is.list(bStrings) == FALSE) {
		stop("CellNOpt Error: 3rd argument called bStrings must be a list of vectors. Each vector representing a bit string")
	}
	if (length(bStrings) == 1) {
		simPrev = carnival_internal_simulateT1(CNOlist, model, bStrings[[1]])
	}
	else if (length(bStrings) > 1) {
		simPrev = carnival_internal_simulateT1(CNOlist, model, bStrings[[1]])
		for (i in 2:length(bStrings)) {
			res = buildBitString(bStrings[1:i])
			simPrev = internal_simulateTN(CNOlist, model, simPrev, 
										  res$bs, res$bsTimes, i + 1)
		}
	}
	return(simPrev)
}

carnival_internal_simulateT1 <- function (CNOlist, model, bStringT1, simList = NULL, indexList = NULL) 
{
	modelCut <- cutModel(model, bStringT1)
	if (is.null(simList) == TRUE) {
		simList = prep4sim(model)
	}
	if (is.null(indexList) == TRUE) {
		indexList = indexFinder(CNOlist, model)
	}
	newSimList = cutSimList(simList, bStringT1)
	simRes <- carnival_simulatorT1(CNOlist = CNOlist, model = modelCut, 
								   simList = newSimList, indexList = indexList)
	return(simRes)
}

carnival_simulatorT1 <- function (CNOlist, model, simList, indexList, mode = 1) 
{
	simRes = carnival_cSimulator(CNOlist, model, simList, indexList, 
								 mode = mode)
	return(simRes)
}


carnival_cSimulator_future <- function(CNOlist, model, simList, indexList, 
									   mode = mode){
	
	
	nStimuli <- as.integer(length(indexList$stimulated))
	nInhibitors <- as.integer(length(indexList$inhibited))
	nCond <- as.integer(dim(CNOlist@stimuli)[1])
	nReacs <- as.integer(length(model$reacID))
	nSpecies <- as.integer(length(model$namesSpecies))
	nMaxInputs <- as.integer(dim(simList$finalCube)[2])
	finalCube = as.integer(simList$finalCube - 1)
	ixNeg = as.integer(simList$ixNeg)
	ignoreCube = as.integer(simList$ignoreCube)
	maxIx = as.integer(simList$maxIx - 1)
	indexSignals <- as.integer(indexList$signals - 1)
	indexStimuli <- as.integer(indexList$stimulated - 1)
	indexInhibitors <- as.integer(indexList$inhibited - 1)
	nSignals <- length(indexSignals)
	valueInhibitors <- as.integer(CNOlist@inhibitors)
	valueStimuli <- as.integer(CNOlist@stimuli)
	res = .Call("simulator_carnival", nStimuli, nInhibitors, nCond, 
				nReacs, nSpecies, nSignals, nMaxInputs, finalCube, ixNeg, 
				ignoreCube, maxIx, indexSignals, indexStimuli, indexInhibitors, 
				valueInhibitors, valueStimuli, as.integer(mode))
	
}

carnival_cSimulator <- function(CNOlist, model, simList, indexList, 
								mode = mode){
	
	
	nStimuli <- as.integer(length(indexList$stimulated))
	nInhibitors <- as.integer(length(indexList$inhibited))
	nCond <- as.integer(dim(CNOlist@stimuli)[1])
	nReacs <- as.integer(length(model$reacID))
	nSpecies <- as.integer(length(model$namesSpecies))
	nMaxInputs <- as.integer(dim(simList$finalCube)[2])
	finalCube = as.integer(simList$finalCube)
	ixNeg = as.integer(simList$ixNeg)
	ignoreCube = as.integer(simList$ignoreCube)
	maxIx = as.integer(simList$maxIx)
	indexSignals <- as.integer(indexList$signals)
	indexStimuli <- as.integer(indexList$stimulated )
	indexInhibitors <- as.integer(indexList$inhibited)
	nSignals <- length(indexSignals)
	valueInhibitors <- as.integer(CNOlist@inhibitors)
	valueStimuli <- as.integer(CNOlist@stimuli)
	

	# nStimuli_in = nStimuli
	# nInhibitors_in=nInhibitors
	# nCond_in= nCond
	# nReacs_in = nReacs
	# nSpecies_in=nSpecies
	# nSignals_in=nSignals
	# nMaxInputs_in=nMaxInputs
	# finalCube_in=finalCube
	# ixNeg_in=ixNeg
	# ignoreCube_in=ignoreCube
	# maxIx_in=maxIx
	# 
	# indexSignals_in = indexSignals
	# indexStimuli_in = indexStimuli
	# indexInhibitors_in = indexInhibitors
	# 
	# valueInhibitors_in = valueInhibitors
	# valueStimuli_in  =valueStimuli
	# mode_in = mode
	# save(nStimuli_in, nInhibitors_in, nCond_in,
	# 	 nReacs_in, nSpecies_in, nSignals_in, nMaxInputs_in, finalCube_in, ixNeg_in,
	# 	 ignoreCube_in, maxIx_in, indexSignals_in, indexStimuli_in, indexInhibitors_in,
	# 	 valueInhibitors_in, valueStimuli_in, mode_in,CNOlist, model, simList, indexList,file = "./carnival_sim_dev/cs_toy_sim_inputs.RData")
	# browser()
	res = simulator_carnival(nStimuli, nInhibitors, nCond,
							 nReacs, nSpecies, nSignals, nMaxInputs, finalCube, ixNeg, 
							 ignoreCube, maxIx, indexSignals, indexStimuli, indexInhibitors, 
							 valueInhibitors, valueStimuli, as.integer(mode))
	
}



# load("./carnival_sim_dev/cs_toy_sim_inputs.RData")

simulator_carnival <- function (
	
	nStimuli_in,
	nInhibitors_in,
	nCond_in,
	nReacs_in,
	nSpecies_in,
	nSignals_in,
	nMaxInputs_in,
	
	finalCube_in,
	ixNeg_in,
	ignoreCube_in,
	maxIx_in,
	
	indexSignals_in,
	indexStimuli_in,
	indexInhibitors_in,
	
	valueInhibitors_in,
	valueStimuli_in,
	mode_in
) {
	
	
	simResults = NULL;
	
	counter = 0;
	i = 0;
	j = 0;
	s = 0;
	a = 0
	b = 0
	p = 0;
	curr_max = 0;
	or_max = 0;
	
	selCounter = 0;
	# double *rans;
	
	count_na_1 = 0;
	count_na_2 = 0;
	
	#/* variables */
	nStimuli = as.integer(nStimuli_in);
	nInhibitors = as.integer(nInhibitors_in);
	nCond = as.integer(nCond_in);
	nReacs = as.integer(nReacs_in);
	nSpecies = as.integer(nSpecies_in);
	nSignals = as.integer(nSignals_in);
	nMaxInputs = as.integer(nMaxInputs_in);
	mode = as.integer(mode_in);
	
	count_species = 0;
	
	
	
	#/* see stop conditions */
	test_val = 1e-3;
	
	track_cond = 0; #/* track condition */
	track_reac = 0; #/* track reaction */
	
	current_min = 0;
	dial_reac = 0;
	dial_cond = 0;
	
	term_check_1 = 1;
	term_check_2 = 1;
	count = 1;
	diff;
	
	#//Rprintf("CellNOpt simulator T1\n");
	
	
	#int *selection;
	selection = c();
	for (i  in  1:nReacs) {
		selection[i] = 0;
	}
	
	
	
	counter = 1;
	
	maxIx = c()
	for (i in 1:nReacs) {
		maxIx[i] = as.integer(maxIx_in)[counter]
		counter = counter + 1
	}
	
	counter = 1;
	
	indexStimuli = c()
	for (i in 1:nStimuli) {
		indexStimuli[i] = as.integer(indexStimuli_in)[counter]
		counter = counter + 1
	}
	
	counter = 1;
	
	indexInhibitors = c()
	for (i in 1:nInhibitors) {
		indexInhibitors[i] = as.integer(indexInhibitors_in)[counter]
		counter = counter + 1
	}
	
	counter = 1;
	
	indexSignals  = c()
	for (i  in 1:nSignals) {
		indexSignals[i] = as.integer(indexSignals_in)[counter] 
		counter = counter + 1
	}
	
	# finalCube: matrix that contains ..
	# int **finalCube;
	finalCube = matrix(data = 0,nrow = nReacs, ncol = nMaxInputs)
	
	for (i in 1:nReacs) {
		for (j in 1:nMaxInputs) {
			finalCube[i,j] = as.integer(finalCube_in)[(j-1) * nReacs + i];
		}
	}
	
	# counter = 0;
	
	# ixNeg: for each reaction (in rows) indicates if the inputs are inhibitory (1)
	# or activation (0). (this is the same across all conditions.) 
	ixNeg = matrix(data = 0,nrow = nReacs, ncol = nMaxInputs)
	
	for (i in 1:nReacs) {
		for (j in 1:nMaxInputs) {
			ixNeg[i,j] = as.integer(ixNeg_in)[(j-1) * nReacs + i];
		}
	}
	rownames(ixNeg) = paste0(paste0("r",1:nReacs))
	colnames(ixNeg) = paste0("reac_input",1:nMaxInputs)
	
	
	# counter = 0;
	# ignoreCube: reactions are represented by a matrix, where each row is a reaction
	# and each column is an input for the reaction. If only OR gates are in the model, this matrix is a column vector. 
	# If there is at least 1 AND gate with N inputs, this is a matrix with N columns.
	# In this case interactions with less than  N parent nodes should be noted. 
	# This is the purpose of the ignoreCube. In the ignoreCube matrix, there are 1s for the 
	# entries that are NOT representing inputs for the reactions and 0-s when they do. 
	ignoreCube = matrix(data = 0,nrow = nReacs, ncol = nMaxInputs)
	
	for (i in 1:nReacs) {
		for (j in 1:nMaxInputs) {
			ignoreCube[i,j] = as.integer(ignoreCube_in)[(j-1) * nReacs + i];
		}
	}
	
	# counter = 0;
	
	
	# valueInhibitors: matrix that contains the state of inhibitors for each condition:
	# 1: if inhibitor is active
	# 0: if inhibitor is inactive,
	# but check code below because it is flipped later! 
	# after "flipping values":
	# IN CELLNOPT: 
	# 1 -> 0: for conditions that have the inhibitor. This is used to block the activity of the node
	# 0-> NA: for the condition without the inhibitor, the node value is unassigned. 
	# IN CARNIVAL:
	# 1 -> -1: for conditions that have the inhibitor. This is used to block the activity of the node
	# 0-> NA: for the condition without the inhibitor, the node value is unassigned. 
	
	valueInhibitors = matrix(data = 0,nrow = nCond, ncol = nInhibitors)
	
	if (mode == 0) {
		for (i in 1:nCond) {
			for (j in seq_len(nInhibitors)) {
				valueInhibitors[i,j] = 1;
			}
		}
	}else {
		
		for (i in seq_len(nCond)) {
			for (j in seq_len(nInhibitors)) {
				valueInhibitors[i,j] = as.integer(valueInhibitors_in)[nCond * (j-1) + i];
			}
		}
	}
	
	#colnames(valueInhibitors) = model$namesSpecies[indexInhibitors]
	
	counter = 0;
	
	# valueStimuli: matrix that contains the state of stimuli for each condition:
	# 1: if stimuli is active
	# 0: if stimuli is inactive,
	valueStimuli = matrix(data = 0,nrow = nCond, ncol = nStimuli)
	
	if (mode == 0) {
		for (i in 1:nCond) {
			for (j in seq_len(nStimuli)) {
				valueStimuli[i,j] = 0;
			}
		}
	}else {
		
		for (i in 1:nCond) {
			for (j in seq_len(nStimuli)) {
				valueStimuli[i,j] = as.integer(valueStimuli_in)[nCond * (j-1) + i];
			}
		}
	}
	
	#colnames(valueStimuli) = model$namesSpecies[indexStimuli]
	
	
	#// fill end_ix - how many reactions have each species as input
	# position is the same as in model$namesSpecies. 
	end_ix = rep(NA,nSpecies);
	count_species = 0;
	for (i in 1:nSpecies) {
		for (j in 1:nReacs) {
			if (i == maxIx[j]) {
				count_species = count_species+1;
			}
		}
		end_ix[i] = count_species;
		count_species = 0;
	}
	#names(end_ix) = model$namesSpecies
	
	#/* see stop conditions */
	test_val = 1e-3;
	
	#/* create an initial values matrix*/
	init_values = matrix(NA,nrow = nCond,ncol = nSpecies);
	for (i in 1:nCond) {
		for (j in 1:nSpecies) {
			init_values[i,j] = NA;
		}
	}
	#colnames(init_values) = model$namesSpecies
	
	# /* set the initial values of the stimuli*/
	for (i in 1:nCond) {
		for (j in 1:nStimuli) {
			init_values[i,indexStimuli[j]] = valueStimuli[i,j];
		}
	}
	
	#/* flip and redefine inhibitors*/
	# after "flipping values":
	# 1 -> 0: for conditions that have the inhibitor. This is used to block the activity of the node
	# 0 -> NA: for the condition without the inhibitor, the node value is unassigned.
	#
	# CARNIVAL modification: 
	# 1 -> -1: for conditions that have the inhibitor. This is used to block the activity of the node
	# 0-> NA: for the condition without the inhibitor, the node value is unassigned. 
	if (nInhibitors>0) {
		for (i in 1:nCond) {
			for (j in 1:nInhibitors) {
				valueInhibitors[i,j] = 0 - valueInhibitors[i,j];
				if (valueInhibitors[i,j] == 0) {
					valueInhibitors[i,j] = NA;
				}
			}
		}
	}
	
	# /* set the initial values of the inhibitors */
	for (i in 1:nCond) {
		for (j in seq_len(nInhibitors)) {
			init_values[i,indexInhibitors[j]] = valueInhibitors[i,j];
		}
	}
	# /* end of initializing the matri init_values */
	
	
	#/* initialize main loop */
	output_prev = matrix(data = 0,nrow = nCond, ncol = nSpecies)
	new_input = matrix(data = 0,nrow = nCond, ncol = nSpecies)
	MA = matrix(data = 0,nrow = nCond, ncol = nSpecies)
	
	
	N_MA = max(3,floor(0.1 * nSpecies))
	
	for (i in 1:nCond) {
		for (j in 1:nSpecies) {
			new_input[i,j] = init_values[i,j];
			MA[i,j] = 0.5;
		}
	}
	
	term_check_1 = 1;
	term_check_2 = 1;
	count = 1;
	
	#/* temp_store: working variable (value changes line to line)
	# 1. for each reaction, in each condition contains the value of the input nodes. 
	# initialized with the output of the previous iteration
	# 2. the sign of the edge is also considered and cells corresponding to inhibitory edge entries are flipped. */
	temp_store = matrix(data = 0,nrow = nCond * nReacs, ncol = nMaxInputs)
	rownames(temp_store) = paste0(rep(paste0("c",1:nCond),nReacs),rep(paste0("r",1:nReacs),each=nCond))
	colnames(temp_store) = paste0("reac_input",1:nMaxInputs)
	
	# browser()
	
	#/* start simulation loop */
	while (term_check_1 && term_check_2) {
		
		#/* copy to outputPrev */
		#	/*        memcpy(output_prev, new_input, sizeof(output_prev));*/
		for (i in 1:nCond) {
			for (j in 1:nSpecies) {
				output_prev[i,j] = new_input[i,j];
			}
		}
	#	colnames(output_prev) = c("EGF", "TNFa", "Jnk", "PI3K", "Raf", "Akt", "Mek", "Erk", "NFkB", "cJun", "Hsp27", "p90RSK")
		#/* fill temp store
		#this is different to R version, through a single loop
		#with conditions */
		track_cond = 0+1; #/* track condition */
		track_reac = 0+1; #/* track reaction */
		
		
		for (i in 1:(nCond * nReacs)) {
			for (j in 1:nMaxInputs) {
				
				#/* initial values of each input */
				temp_store[i,j] = output_prev[track_cond,finalCube[track_reac,j]];
				
				# set the unused entries of temp_store to NA
				if (ignoreCube[track_reac,j]) {
					temp_store[i,j] = NA;
				}
				# flip the values of input if the reaction has negative sign (ixNeg is 1). 
				if (ixNeg[track_reac,j] == 1 & !is.na(temp_store[i,j])) {
					#/* flip the values of the neg inputs */
					
					if (temp_store[i,j] == 0) {
						# 0 in 0 out
						temp_store[i,j] = 0;
					}else if (temp_store[i,j] == 1) {
						# 1 -> -1
							temp_store[i,j] = -1;
					}else if (temp_store[i,j] == -1) {
						# -1 -> 1
						temp_store[i,j] = 1;
					}
				}
				
			}
			
			track_cond = track_cond +1 
			if (track_cond == nCond+1) {
				track_cond = 0+1;
				track_reac = track_reac+1
			}
		}
		#browser()
		temp_store_mat = matrix(temp_store,nCond,nReacs)
		colnames(temp_store_mat) = paste0("R",1:nReacs)
		#colnames(temp_store_mat) = model$reacID
		rownames(temp_store_mat) = paste0("C",1:nCond)
		
		
		#/* compute the AND gates (find the min 0/1 of each row) */
		output_cube = matrix(data = 0,nrow = nCond, ncol = nReacs)
		#colnames(output_cube) = model$reacID
		rownames(output_cube) = paste0("C",1:nCond)
		
		#browser()
		dial_reac = 0+1;
		dial_cond = 0+1;
		# AND gate rules: 
		# R1:  anything with NA should be NA
		# R2: 0s and 1s should be 0
		# R3: 0s and -1s should be 0
		# R4: 1s should lead to 1
		# R5: -1s should lead to -1
		# R6: mixture of -1 and 1 should lead to NA
		#
		#  originally the variable current_min is used, but we should rename it
		current_state = NA
		
		for (i in 1:(nCond * nReacs)) {
			current_state = temp_store[i,0+1];
			
			for (j in seq_len(nMaxInputs)) {
				#
				
				if( ignoreCube[dial_reac,j] == 0){
					#/* R1: if statement below is for AND gates with any NA (2) input
					# in this case output should always be NA */
					if (is.na(temp_store[i,j])){
						current_state = NA;
						break;
					}
					
					#/* R6: if the current state and the input is 2 value apart, i.e.
					# one is 1 and the other is -1, then the result should be NA*/
					abs_diff = abs(temp_store[i,j] - current_state) 
					if (abs_diff> 1) {
						current_state = NA;
					}else if (abs_diff == 1) {
						#/* R2, R3: current state and temp is just 1 apart. 
						current_state = 0;
					}else {# abs_diff ==0; R4 R5 automatically
						current_state = temp_store[i,j];
					}
				}
			}
			
			output_cube[dial_cond,dial_reac] = current_state;
			dial_cond=dial_cond+1;
			if (dial_cond == nCond+1) {
				dial_cond = 1
				dial_reac = dial_reac+1
			}
		}
		
		# /* compute the OR gates and reinitialize new_input */
		for (i in 1:nCond) {
			for (j in 1:nSpecies) {
				new_input[i,j] = NA;
			}
		}
		
		#/* declare vector to store 'selection' (R) */
		# /* The first selCounter number of positions in the vector "selection" contains
		# the index of the reactions that influence the current node. */
		selCounter = 0;
		for (s in 1:nSpecies) {
			#/* is the species an output for any reactions?*/
			if (end_ix[s] > 0) {
				
				#/* find reactions with this species as output
				#add equivalent output_cube data to new_input*/
				
				for (a in 1:nReacs) {
					if (s == maxIx[a]) {
						selection[selCounter+1] = a;
						selCounter = selCounter+1}
				}
				# // Rprintf("checkpoint 4\n");
				#/* if the species is an output for a single reaction
				# it's a 1-1 mapping to new_input */
				if (selCounter == 1) {
					for (b in 1:nCond) {
						
						new_input[b,s] = output_cube[b,selection[selCounter]];  
					}
					selCounter = 0;
				}
				#/* else if species is output for > 1 reactions */
				# Special OR gate rules for CARNIVAL: 
				# R1: Node gets NA if all input reactions are NA
				# R2: if inputs are mixed +1 and -1 then NA. 
				# R3: if inputs are mixed 0s and 1, then 1
				# R4: if inputs are mixed 0s and -1, then -1
				if (selCounter > 1) {
					for (i in 1:nCond) {
						or_max = NA;
						curr_max = 0;
						found_one = 0;
						found_minus_one = 0;
						
						for (p in seq_len(selCounter)) {
							
							# R1: we dont update the or_max=NA if all inputs are NA
							if (!is.na(output_cube[i,selection[p]])){
								# if we are here, we had a numeric input (non-NA)
								
								# if the difference is 2, then there must be a 1 and a -1 among the inputs -> output should be NA (R2)
								if(abs(output_cube[i,selection[p]] - curr_max) > 1){
									or_max   = NA;
									curr_max = NA;
									break
								}
								
								# if we found difference of 1, then we need to test,
								# if R2 is the case or not. I.e. if the current output_cube is 
								# 1 then we should set the or_max to NA if we seen -1 before, otherwise to 1. 
								if(abs(output_cube[i,selection[p]] - curr_max) == 1){
									
									if(output_cube[i,selection[p]] == 1){ # curr_max is 0
										if(found_minus_one == 1){
											or_max = NA
											curr_max = NA;
											break
										}else{
											or_max = 1;
											curr_max = 1;
										}
										
									}else if(output_cube[i,selection[p]] == -1){
										
										if(found_one == 1){
											or_max = NA
											curr_max = NA;
											break
										}else{
											or_max = -1;
											curr_max = -1;
										}
										
									} # else output_cube is 0, which does not change. 
									
									
								}
								# if the difference is 0, nothing to do. 
								
							}
							
						}
						new_input[i,s] = or_max;
					}
					selCounter = 0;
				}
			}
		}
		#colnames(new_input) = model$namesSpecies
		
		#/* reset the stimuli */
		for (i in seq_len(nCond)) {
			for (j in seq_len(nStimuli)) {
				curr_max = valueStimuli[i,j];
				
				if (!is.na(new_input[i,indexStimuli[j]] && new_input[i,indexStimuli[j]] > curr_max )) {
					curr_max = new_input[i,indexStimuli[j]];
				}
				
				new_input[i,indexStimuli[j]] = curr_max;
			}
		}
		#browser()
		#/* reset the inhibitors */
		for (i in seq_len(nCond)) {
			for (j in seq_len(nInhibitors)) {
				if (mode == 1) {
					if (!is.na(valueInhibitors[i,j]) && valueInhibitors[i,j] == -1) {
						new_input[i,indexInhibitors[j]] = -1;
					}
				}
				else {
					
					# /* BUG FIX Sept 2014, TC*/
					# /* at time0, inhibitors are all off by default. So, we do
					#  * not want to reset their content at each tick. There is
					#  * not need for the code above. This is especially important
					#  * if a node if both inhibted and a readout and/or there
					#  * are input links that are inhibitors*/
				}
			}
		}
		
		
		count_na_1 = 0;
		count_na_2 = 0;
		#/* set 'NAs' (2s) to 0 */
		for (i in seq_len(nCond)) {
			for (j in 1:nSpecies) {
				if (is.na(new_input[i,j])) {
					count_na_1=count_na_1+1 ;
					new_input[i,j] = 0;
				}
				if (is.na(output_prev[i,j])) {
					count_na_2=count_na_2+1 ;
					output_prev[i,j] = 0;
				}
			}
		}
		
		
		term_check_1 = 0;
		for (i in 1:nCond) {
			for (j in 1:nSpecies) {
				diff = abs((new_input[i,j] - output_prev[i,j]));
				if (diff > test_val) {
					term_check_1 = 1;
					break;  #/*  no need to keep going checking other values if
					#   one is greater than test_val */
				}
			}
			#//            printf("\n");
		}
		if (count_na_1 != count_na_2) {
			term_check_1 = 1;
		}
		if (count == nSpecies) {
			#           /* initialise moving average for each state
			#          By interation nSpecies +1 all states are updated at least once, and steady states are achieved. 
			#         */
			for (i in 1:nCond) {
				for (j in 1:nSpecies) {
					MA[i,j] = new_input[i,j];
				}
			}
			
		}
		if (count > nSpecies) {
			#// compute moving average for each state in each condition
			for (i in 1:nCond) {
				for (j in 1:nSpecies) {
					MA[i,j] = MA[i,j] * (N_MA - 1) / N_MA + (new_input[i,j]) / N_MA;
				}
			}
			#//Rprintf("l 460\n");
			#//RprintMA(&MA[0][0], nCond, nSpecies);
		}
		#/*term_check_1 = !(abs(diff) < test_val);*/
		term_check_2 = (count < (nSpecies * 1.2));
		count = count+1;
		
	}
	#//Rprintf("end of while:\n");
	#//RprintStatus(&new_input[0][0], nCond, nSpecies);
	
	
	#/* set non-resolved bits to 2 (NA)*/
	for (i in 1:nCond) {
		for (j in 1:nSpecies) {
			if (new_input[i,j] != output_prev[i,j])
				new_input[i,j] = NA;
		}
	}
	#//Rprintf("set non-resolved bits to 2 (NA):\n");
	#//RprintStatus(&new_input[0][0], nCond, nSpecies);
	
	# /* set oscillating bits to 2 (NA)*/
	if(count > nSpecies+1){
		for (i in 1:nCond) {
			for (j in 1:nSpecies) {
				if (MA[i,j]<0.95 & MA[i,j]>0.05)  #// actually we could check if they are exactly 0 or 1
					new_input[i,j] = NA;
			}
		}
	}
	# //Rprintf("l 489\n");
	# //RprintMA(&MA[0][0], nCond, nSpecies);
	# //Rprintf("set oscillating bits to 2 (NA):\n");
	# //RprintStatus(&new_input[0][0], nCond, nSpecies);
	
	simResults = matrix(data = 0,nrow = nCond, ncol = nSpecies) 
	rans = c()
	for (i in 1:nCond) {
		for (j in 1:nSpecies) {
			if (is.na(new_input[i,j])) {
				simResults[i + nCond * (j-1)] = NA;
			} else simResults[i + nCond * (j-1)] = new_input[i,j];
		}
	}
	
	# /* this code works but raise issue when calling simulatorT1 */
	# /*     PROTECT(simResults = allocMatrix(REALSXP, nCond, nSignals));
	#     rans = c();
	#     for(i in 1:nCond) {
	#         for(j in 1:nSignals) {
	#             if(is.na(new_input[i][indexSignals[j]])){
	#             	rans[i + nCond*(j-1)] = NA
	#             	} else rans[i + nCond*(j-1)] = new_input[i][indexSignals[j]];
	#         }
	#     }
	# */
	
	
	# free(maxIx);
	# // Rprintf("checkpoint 6\n");
	# free(selection);
	# // Rprintf("checkpoint 7\n");
	# free(indexStimuli);
	# free(indexInhibitors);
	# free(indexSignals);
	
	# for (i = 0; i < nReacs; i++) {
	#     free(finalCube[i]);
	# }
	# free(finalCube);
	# 
	# for (i = 0; i < nReacs; i++) {
	#     free(ixNeg[i]);
	# }
	# free(ixNeg);
	# 
	# for (i = 0; i < nReacs; i++) {
	#     free(ignoreCube[i]);
	# }
	# free(ignoreCube);
	# 
	# for (i = 0; i < nCond; i++) {
	#     free(valueInhibitors[i]);
	# }
	# free(valueInhibitors);
	# 
	# for (i = 0; i < nCond; i++) {
	#     free(valueStimuli[i]);
	# }
	# free(valueStimuli);
	# 
	# UNPROTECT(1);
	return (simResults)
	
}


