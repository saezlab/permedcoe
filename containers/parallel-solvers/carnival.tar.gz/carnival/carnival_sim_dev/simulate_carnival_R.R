

simulator_carnival <- function (
	
	nStimuli_in,
	nInhibitors_in,
	nCond_in,
	nReacs_in,
	nSpecies_in,
	nSignals_in,
	nMaxInputs_in,
	
	finalCube_in,
	ixNeg_in,
	ignoreCube_in,
	maxIx_in,
	
	indexSignals_in,
	indexStimuli_in,
	indexInhibitors_in,
	
	valueInhibitors_in,
	valueStimuli_in,
	mode_in
) {
	
	
	simResults = NULL;
	
	counter = 0;
	i = 0;
	j = 0;
	s = 0;
	a = 0
	b = 0
	p = 0;
	curr_max = 0;
	or_max = 0;
	
	selCounter = 0;
	# double *rans;
	
	count_na_1 = 0;
	count_na_2 = 0;
	
	#/* variables */
	nStimuli = as.integer(nStimuli_in);
	nInhibitors = as.integer(nInhibitors_in);
	nCond = as.integer(nCond_in);
	nReacs = as.integer(nReacs_in);
	nSpecies = as.integer(nSpecies_in);
	nSignals = as.integer(nSignals_in);
	nMaxInputs = as.integer(nMaxInputs_in);
	mode = as.integer(mode_in);
	
	count_species = 0;
	
	
	
	#/* see stop conditions */
	test_val = 1e-3;
	
	track_cond = 0; #/* track condition */
	track_reac = 0; #/* track reaction */
	
	current_min = 0;
	dial_reac = 0;
	dial_cond = 0;
	
	term_check_1 = 1;
	term_check_2 = 1;
	count = 1;
	diff;
	
	#//Rprintf("CellNOpt simulator T1\n");
	
	
	#int *selection;
	selection = c();
	for (i  in  1:nReacs) {
		selection[i] = 0;
	}
	
	
	
	counter = 1;
	
	maxIx = c()
	for (i in 1:nReacs) {
		maxIx[i] = as.integer(maxIx_in)[counter]
		counter = counter + 1
	}
	
	counter = 1;
	
	indexStimuli = c()
	for (i in 1:nStimuli) {
		indexStimuli[i] = as.integer(indexStimuli_in)[counter]
		counter = counter + 1
	}
	
	counter = 1;
	
	indexInhibitors = c()
	for (i in 1:nInhibitors) {
		indexInhibitors[i] = as.integer(indexInhibitors_in)[counter]
		counter = counter + 1
	}
	
	counter = 1;
	
	indexSignals  = c()
	for (i  in 1:nSignals) {
		indexSignals[i] = as.integer(indexSignals_in)[counter] 
		counter = counter + 1
	}
	
	# finalCube: matrix that contains ..
	# int **finalCube;
	finalCube = matrix(data = 0,nrow = nReacs, ncol = nMaxInputs)
	
	for (i in 1:nReacs) {
		for (j in 1:nMaxInputs) {
			finalCube[i,j] = as.integer(finalCube_in)[(j-1) * nReacs + i];
		}
	}
	
	# counter = 0;
	
	# ixNeg: for each reaction (in rows) indicates if the inputs are inhibitory (1)
	# or activation (0). (this is the same across all conditions.) 
	ixNeg = matrix(data = 0,nrow = nReacs, ncol = nMaxInputs)
	
	for (i in 1:nReacs) {
		for (j in 1:nMaxInputs) {
			ixNeg[i,j] = as.integer(ixNeg_in)[(j-1) * nReacs + i];
		}
	}
	rownames(ixNeg) = paste0(paste0("r",1:nReacs))
	colnames(ixNeg) = paste0("reac_input",1:nMaxInputs)
	
	
	# counter = 0;
	# ignoreCube: reactions are represented by a matrix, where each row is a reaction
	# and each column is an input for the reaction. If only OR gates are in the model, this matrix is a column vector. 
	# If there is at least 1 AND gate with N inputs, this is a matrix with N columns.
	# In this case interactions with less than  N parent nodes should be noted. 
	# This is the purpose of the ignoreCube. In the ignoreCube matrix, there are 1s for the 
	# entries that are NOT representing inputs for the reactions and 0-s when they do. 
	ignoreCube = matrix(data = 0,nrow = nReacs, ncol = nMaxInputs)
	
	for (i in 1:nReacs) {
		for (j in 1:nMaxInputs) {
			ignoreCube[i,j] = as.integer(ignoreCube_in)[(j-1) * nReacs + i];
		}
	}
	
	# counter = 0;
	
	
	# valueInhibitors: matrix that contains the state of inhibitors for each condition:
	# 1: if inhibitor is active
	# 0: if inhibitor is inactive,
	# but check code below because it is flipped later! 
	# after "flipping values":
	# IN CELLNOPT: 
	# 1 -> 0: for conditions that have the inhibitor. This is used to block the activity of the node
	# 0-> NA: for the condition without the inhibitor, the node value is unassigned. 
	# IN CARNIVAL:
	# 1 -> -1: for conditions that have the inhibitor. This is used to block the activity of the node
	# 0-> NA: for the condition without the inhibitor, the node value is unassigned. 
	
	valueInhibitors = matrix(data = 0,nrow = nCond, ncol = nInhibitors)
	
	if (mode == 0) {
		for (i in 1:nCond) {
			for (j in seq_len(nInhibitors)) {
				valueInhibitors[i,j] = 1;
			}
		}
	}else {
		
		for (i in seq_len(nCond)) {
			for (j in seq_len(nInhibitors)) {
				valueInhibitors[i,j] = as.integer(valueInhibitors_in)[nCond * (j-1) + i];
			}
		}
	}
	
	#colnames(valueInhibitors) = model$namesSpecies[indexInhibitors]
	
	counter = 0;
	
	# valueStimuli: matrix that contains the state of stimuli for each condition:
	# 1: if stimuli is active
	# 0: if stimuli is inactive,
	valueStimuli = matrix(data = 0,nrow = nCond, ncol = nStimuli)
	
	if (mode == 0) {
		for (i in 1:nCond) {
			for (j in seq_len(nStimuli)) {
				valueStimuli[i,j] = 0;
			}
		}
	}else {
		
		for (i in 1:nCond) {
			for (j in seq_len(nStimuli)) {
				valueStimuli[i,j] = as.integer(valueStimuli_in)[nCond * (j-1) + i];
			}
		}
	}
	
	#colnames(valueStimuli) = model$namesSpecies[indexStimuli]
	
	
	#// fill end_ix - how many reactions have each species as input
	# position is the same as in model$namesSpecies. 
	end_ix = rep(NA,nSpecies);
	count_species = 0;
	for (i in 1:nSpecies) {
		for (j in 1:nReacs) {
			if (i == maxIx[j]) {
				count_species = count_species+1;
			}
		}
		end_ix[i] = count_species;
		count_species = 0;
	}
	#names(end_ix) = model$namesSpecies
	
	#/* see stop conditions */
	test_val = 1e-3;
	
	#/* create an initial values matrix*/
	init_values = matrix(NA,nrow = nCond,ncol = nSpecies);
	for (i in 1:nCond) {
		for (j in 1:nSpecies) {
			init_values[i,j] = NA;
		}
	}
	#colnames(init_values) = model$namesSpecies
	
	# /* set the initial values of the stimuli*/
	for (i in 1:nCond) {
		for (j in 1:nStimuli) {
			init_values[i,indexStimuli[j]] = valueStimuli[i,j];
		}
	}
	
	#/* flip and redefine inhibitors*/
	# after "flipping values":
	# 1 -> 0: for conditions that have the inhibitor. This is used to block the activity of the node
	# 0 -> NA: for the condition without the inhibitor, the node value is unassigned.
	#
	# CARNIVAL modification: 
	# 1 -> -1: for conditions that have the inhibitor. This is used to block the activity of the node
	# 0-> NA: for the condition without the inhibitor, the node value is unassigned. 
	if (nInhibitors>0) {
		for (i in 1:nCond) {
			for (j in 1:nInhibitors) {
				valueInhibitors[i,j] = 0 - valueInhibitors[i,j];
				if (valueInhibitors[i,j] == 0) {
					valueInhibitors[i,j] = NA;
				}
			}
		}
	}
	
	# /* set the initial values of the inhibitors */
	for (i in 1:nCond) {
		for (j in seq_len(nInhibitors)) {
			init_values[i,indexInhibitors[j]] = valueInhibitors[i,j];
		}
	}
	# /* end of initializing the matri init_values */
	
	
	#/* initialize main loop */
	output_prev = matrix(data = 0,nrow = nCond, ncol = nSpecies)
	new_input = matrix(data = 0,nrow = nCond, ncol = nSpecies)
	MA = matrix(data = 0,nrow = nCond, ncol = nSpecies)
	
	
	N_MA = max(3,floor(0.1 * nSpecies))
	
	for (i in 1:nCond) {
		for (j in 1:nSpecies) {
			new_input[i,j] = init_values[i,j];
			MA[i,j] = 0.5;
		}
	}
	
	term_check_1 = 1;
	term_check_2 = 1;
	count = 1;
	
	#/* temp_store: working variable (value changes line to line)
	# 1. for each reaction, in each condition contains the value of the input nodes. 
	# initialized with the output of the previous iteration
	# 2. the sign of the edge is also considered and cells corresponding to inhibitory edge entries are flipped. */
	temp_store = matrix(data = 0,nrow = nCond * nReacs, ncol = nMaxInputs)
	rownames(temp_store) = paste0(rep(paste0("c",1:nCond),nReacs),rep(paste0("r",1:nReacs),each=nCond))
	colnames(temp_store) = paste0("reac_input",1:nMaxInputs)
	
	# browser()
	
	#/* start simulation loop */
	while (term_check_1 && term_check_2) {
		
		#/* copy to outputPrev */
		#	/*        memcpy(output_prev, new_input, sizeof(output_prev));*/
		for (i in 1:nCond) {
			for (j in 1:nSpecies) {
				output_prev[i,j] = new_input[i,j];
			}
		}
	#	colnames(output_prev) = c("EGF", "TNFa", "Jnk", "PI3K", "Raf", "Akt", "Mek", "Erk", "NFkB", "cJun", "Hsp27", "p90RSK")
		#/* fill temp store
		#this is different to R version, through a single loop
		#with conditions */
		track_cond = 0+1; #/* track condition */
		track_reac = 0+1; #/* track reaction */
		
		
		for (i in 1:(nCond * nReacs)) {
			for (j in 1:nMaxInputs) {
				
				#/* initial values of each input */
				temp_store[i,j] = output_prev[track_cond,finalCube[track_reac,j]];
				
				# set the unused entries of temp_store to NA
				if (ignoreCube[track_reac,j]) {
					temp_store[i,j] = NA;
				}
				# flip the values of input if the reaction has negative sign (ixNeg is 1). 
				if (ixNeg[track_reac,j] == 1 & !is.na(temp_store[i,j])) {
					#/* flip the values of the neg inputs */
					
					if (temp_store[i,j] == 0) {
						# 0 in 0 out
						temp_store[i,j] = 0;
					}else if (temp_store[i,j] == 1) {
						# 1 -> -1
							temp_store[i,j] = -1;
					}else if (temp_store[i,j] == -1) {
						# -1 -> 1
						temp_store[i,j] = 1;
					}
				}
				
			}
			
			track_cond = track_cond +1 
			if (track_cond == nCond+1) {
				track_cond = 0+1;
				track_reac = track_reac+1
			}
		}
		#browser()
		temp_store_mat = matrix(temp_store,nCond,nReacs)
		colnames(temp_store_mat) = paste0("R",1:nReacs)
		#colnames(temp_store_mat) = model$reacID
		rownames(temp_store_mat) = paste0("C",1:nCond)
		
		
		#/* compute the AND gates (find the min 0/1 of each row) */
		output_cube = matrix(data = 0,nrow = nCond, ncol = nReacs)
		#colnames(output_cube) = model$reacID
		rownames(output_cube) = paste0("C",1:nCond)
		
		#browser()
		dial_reac = 0+1;
		dial_cond = 0+1;
		# AND gate rules: 
		# R1:  anything with NA should be NA
		# R2: 0s and 1s should be 0
		# R3: 0s and -1s should be 0
		# R4: 1s should lead to 1
		# R5: -1s should lead to -1
		# R6: mixture of -1 and 1 should lead to NA
		#
		#  originally the variable current_min is used, but we should rename it
		current_state = NA
		
		for (i in 1:(nCond * nReacs)) {
			current_state = temp_store[i,0+1];
			
			for (j in seq_len(nMaxInputs)) {
				#
				
				if( ignoreCube[dial_reac,j] == 0){
					#/* R1: if statement below is for AND gates with any NA (2) input
					# in this case output should always be NA */
					if (is.na(temp_store[i,j])){
						current_state = NA;
						break;
					}
					
					#/* R6: if the current state and the input is 2 value apart, i.e.
					# one is 1 and the other is -1, then the result should be NA*/
					abs_diff = abs(temp_store[i,j] - current_state) 
					if (abs_diff> 1) {
						current_state = NA;
					}else if (abs_diff == 1) {
						#/* R2, R3: current state and temp is just 1 apart. 
						current_state = 0;
					}else {# abs_diff ==0; R4 R5 automatically
						current_state = temp_store[i,j];
					}
				}
			}
			
			output_cube[dial_cond,dial_reac] = current_state;
			dial_cond=dial_cond+1;
			if (dial_cond == nCond+1) {
				dial_cond = 1
				dial_reac = dial_reac+1
			}
		}
		
		# /* compute the OR gates and reinitialize new_input */
		for (i in 1:nCond) {
			for (j in 1:nSpecies) {
				new_input[i,j] = NA;
			}
		}
		
		#/* declare vector to store 'selection' (R) */
		# /* The first selCounter number of positions in the vector "selection" contains
		# the index of the reactions that influence the current node. */
		selCounter = 0;
		for (s in 1:nSpecies) {
			#/* is the species an output for any reactions?*/
			if (end_ix[s] > 0) {
				
				#/* find reactions with this species as output
				#add equivalent output_cube data to new_input*/
				
				for (a in 1:nReacs) {
					if (s == maxIx[a]) {
						selection[selCounter+1] = a;
						selCounter = selCounter+1}
				}
				# // Rprintf("checkpoint 4\n");
				#/* if the species is an output for a single reaction
				# it's a 1-1 mapping to new_input */
				if (selCounter == 1) {
					for (b in 1:nCond) {
						
						new_input[b,s] = output_cube[b,selection[selCounter]];  
					}
					selCounter = 0;
				}
				#/* else if species is output for > 1 reactions */
				# Special OR gate rules for CARNIVAL: 
				# R1: Node gets NA if all input reactions are NA
				# R2: if inputs are mixed +1 and -1 then NA. 
				# R3: if inputs are mixed 0s and 1, then 1
				# R4: if inputs are mixed 0s and -1, then -1
				if (selCounter > 1) {
					for (i in 1:nCond) {
						or_max = NA;
						curr_max = 0;
						found_one = 0;
						found_minus_one = 0;
						
						for (p in seq_len(selCounter)) {
							
							# R1: we dont update the or_max=NA if all inputs are NA
							if (!is.na(output_cube[i,selection[p]])){
								# if we are here, we had a numeric input (non-NA)
								
								# if the difference is 2, then there must be a 1 and a -1 among the inputs -> output should be NA (R2)
								if(abs(output_cube[i,selection[p]] - curr_max) > 1){
									or_max   = NA;
									curr_max = NA;
									break
								}
								
								# if we found difference of 1, then we need to test,
								# if R2 is the case or not. I.e. if the current output_cube is 
								# 1 then we should set the or_max to NA if we seen -1 before, otherwise to 1. 
								if(abs(output_cube[i,selection[p]] - curr_max) == 1){
									
									if(output_cube[i,selection[p]] == 1){ # curr_max is 0
										if(found_minus_one == 1){
											or_max = NA
											curr_max = NA;
											break
										}else{
											or_max = 1;
											curr_max = 1;
										}
										
									}else if(output_cube[i,selection[p]] == -1){
										
										if(found_one == 1){
											or_max = NA
											curr_max = NA;
											break
										}else{
											or_max = -1;
											curr_max = -1;
										}
										
									} # else output_cube is 0, which does not change. 
									
									
								}
								# if the difference is 0, nothing to do. 
								
							}
							
						}
						new_input[i,s] = or_max;
					}
					selCounter = 0;
				}
			}
		}
		#colnames(new_input) = model$namesSpecies
		
		#/* reset the stimuli */
		for (i in seq_len(nCond)) {
			for (j in seq_len(nStimuli)) {
				curr_max = valueStimuli[i,j];
				
				if (!is.na(new_input[i,indexStimuli[j]] && new_input[i,indexStimuli[j]] > curr_max )) {
					curr_max = new_input[i,indexStimuli[j]];
				}
				
				new_input[i,indexStimuli[j]] = curr_max;
			}
		}
		#browser()
		#/* reset the inhibitors */
		for (i in seq_len(nCond)) {
			for (j in seq_len(nInhibitors)) {
				if (mode == 1) {
					if (!is.na(valueInhibitors[i,j]) && valueInhibitors[i,j] == -1) {
						new_input[i,indexInhibitors[j]] = -1;
					}
				}
				else {
					
					# /* BUG FIX Sept 2014, TC*/
					# /* at time0, inhibitors are all off by default. So, we do
					#  * not want to reset their content at each tick. There is
					#  * not need for the code above. This is especially important
					#  * if a node if both inhibted and a readout and/or there
					#  * are input links that are inhibitors*/
				}
			}
		}
		
		
		count_na_1 = 0;
		count_na_2 = 0;
		#/* set 'NAs' (2s) to 0 */
		for (i in seq_len(nCond)) {
			for (j in 1:nSpecies) {
				if (is.na(new_input[i,j])) {
					count_na_1=count_na_1+1 ;
					new_input[i,j] = 0;
				}
				if (is.na(output_prev[i,j])) {
					count_na_2=count_na_2+1 ;
					output_prev[i,j] = 0;
				}
			}
		}
		
		
		term_check_1 = 0;
		for (i in 1:nCond) {
			for (j in 1:nSpecies) {
				diff = abs((new_input[i,j] - output_prev[i,j]));
				if (diff > test_val) {
					term_check_1 = 1;
					break;  #/*  no need to keep going checking other values if
					#   one is greater than test_val */
				}
			}
			#//            printf("\n");
		}
		if (count_na_1 != count_na_2) {
			term_check_1 = 1;
		}
		if (count == nSpecies) {
			#           /* initialise moving average for each state
			#          By interation nSpecies +1 all states are updated at least once, and steady states are achieved. 
			#         */
			for (i in 1:nCond) {
				for (j in 1:nSpecies) {
					MA[i,j] = new_input[i,j];
				}
			}
			
		}
		if (count > nSpecies) {
			#// compute moving average for each state in each condition
			for (i in 1:nCond) {
				for (j in 1:nSpecies) {
					MA[i,j] = MA[i,j] * (N_MA - 1) / N_MA + (new_input[i,j]) / N_MA;
				}
			}
			#//Rprintf("l 460\n");
			#//RprintMA(&MA[0][0], nCond, nSpecies);
		}
		#/*term_check_1 = !(abs(diff) < test_val);*/
		term_check_2 = (count < (nSpecies * 1.2));
		count = count+1;
		
	}
	#//Rprintf("end of while:\n");
	#//RprintStatus(&new_input[0][0], nCond, nSpecies);
	
	
	#/* set non-resolved bits to 2 (NA)*/
	for (i in 1:nCond) {
		for (j in 1:nSpecies) {
			if (new_input[i,j] != output_prev[i,j])
				new_input[i,j] = NA;
		}
	}
	#//Rprintf("set non-resolved bits to 2 (NA):\n");
	#//RprintStatus(&new_input[0][0], nCond, nSpecies);
	
	# /* set oscillating bits to 2 (NA)*/
	if(count > nSpecies+1){
		for (i in 1:nCond) {
			for (j in 1:nSpecies) {
				if (MA[i,j]<0.95 & MA[i,j]>0.05)  #// actually we could check if they are exactly 0 or 1
					new_input[i,j] = NA;
			}
		}
	}
	# //Rprintf("l 489\n");
	# //RprintMA(&MA[0][0], nCond, nSpecies);
	# //Rprintf("set oscillating bits to 2 (NA):\n");
	# //RprintStatus(&new_input[0][0], nCond, nSpecies);
	
	simResults = matrix(data = 0,nrow = nCond, ncol = nSpecies) 
	rans = c()
	for (i in 1:nCond) {
		for (j in 1:nSpecies) {
			if (is.na(new_input[i,j])) {
				simResults[i + nCond * (j-1)] = NA;
			} else simResults[i + nCond * (j-1)] = new_input[i,j];
		}
	}
	
	# /* this code works but raise issue when calling simulatorT1 */
	# /*     PROTECT(simResults = allocMatrix(REALSXP, nCond, nSignals));
	#     rans = c();
	#     for(i in 1:nCond) {
	#         for(j in 1:nSignals) {
	#             if(is.na(new_input[i][indexSignals[j]])){
	#             	rans[i + nCond*(j-1)] = NA
	#             	} else rans[i + nCond*(j-1)] = new_input[i][indexSignals[j]];
	#         }
	#     }
	# */
	
	
	# free(maxIx);
	# // Rprintf("checkpoint 6\n");
	# free(selection);
	# // Rprintf("checkpoint 7\n");
	# free(indexStimuli);
	# free(indexInhibitors);
	# free(indexSignals);
	
	# for (i = 0; i < nReacs; i++) {
	#     free(finalCube[i]);
	# }
	# free(finalCube);
	# 
	# for (i = 0; i < nReacs; i++) {
	#     free(ixNeg[i]);
	# }
	# free(ixNeg);
	# 
	# for (i = 0; i < nReacs; i++) {
	#     free(ignoreCube[i]);
	# }
	# free(ignoreCube);
	# 
	# for (i = 0; i < nCond; i++) {
	#     free(valueInhibitors[i]);
	# }
	# free(valueInhibitors);
	# 
	# for (i = 0; i < nCond; i++) {
	#     free(valueStimuli[i]);
	# }
	# free(valueStimuli);
	# 
	# UNPROTECT(1);
	return (simResults)
	
}


