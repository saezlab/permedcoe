// Brace on same line than *union* definitions

union foo {
    int x;
}
