// Access Modifiers Indentation inside `struct` and `class`
// access modifiers may be indented this way:
class Foo {
  public:
    Foo();

  private:
    int data;
};
