// Use 4 columns for indentation

void f() {
    someFunction();
    if (true, false) {
        f();
    }
}
