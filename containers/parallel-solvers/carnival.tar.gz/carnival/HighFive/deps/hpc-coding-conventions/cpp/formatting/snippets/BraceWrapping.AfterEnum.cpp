// Brace on same line than *enum* definition

enum X : int { A, B, C };
