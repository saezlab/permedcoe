// Horizontally align arguments after an open bracket

thisIsAVeryLongMethodName(thisIsTheFirstArgument,
                          andHereIsTheSecondArgument,
                          theThirdArgument,
                          theFourthArgument,
                          theFifthArgument);
