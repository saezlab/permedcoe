// Brace is on same line than control statements

if (foo()) {
} else {
}
for (int i = 0; i < 10; ++i) {
}
