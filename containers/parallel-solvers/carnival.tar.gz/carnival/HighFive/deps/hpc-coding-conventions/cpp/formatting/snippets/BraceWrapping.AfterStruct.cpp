// Brace on same line than *struct* definitions

struct foo {
    int x;
};
