// break before long ternary operators

veryVeryVeryVeryVeryVeryVeryVeryVeryVeryVeryLongDescription ? firstValue
                                                            : SecondValueVeryVeryVeryVeryLong;
