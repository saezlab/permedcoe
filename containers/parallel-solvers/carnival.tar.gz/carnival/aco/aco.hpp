/**
 * @file aco.hpp
 * @author patricia.gonzalez@udc.es
 * @brief Header file for the program.
 */

/* comment this define appropriately */
#define MPI2
#define OMP

#ifdef MPI2
   #include <mpi.h>
#endif

/**************** RANDOM NUMBERS *********************/

#define __MTWISTER_H

#define STATE_VECTOR_LENGTH 624
#define STATE_VECTOR_M      397 /* changes to STATE_VECTOR_LENGTH also require changes to this */

typedef struct tagMTRand {
    unsigned long mt[STATE_VECTOR_LENGTH];
    int index;
} MTRand;

MTRand seedRand(unsigned long seed);
unsigned long genRandLong(MTRand* rand);
double genRand(MTRand* rand);

extern MTRand seedR;

/***************************** ANTS **************************************/
#define HEURISTIC(m,n)     (1.0 / ((double) 0.1))
/* add a small constant to avoid division by zero if a distance is 
zero */

#define EPSILON            0.00000000000000000000000000000001

#define MAX_INDIVIDUALS       1024    /* max no. of individuals */

typedef struct node_struct {
    int  *solution;
    double score;
    struct node_struct *next;
} node;

typedef struct list_struct {
    node *first;
    node *last;
    int size;
} list;

extern list *listSolutions;

void init_list( list *list );
int push_list( list *list, int *solution, double sc);
int pop_list( list *list );
void destroy_list( list *list );


typedef struct {
    int  *solution;
    double  score;
} individual_struct;

extern individual_struct *individual;      /* this (array of) struct will hold the population */
extern individual_struct *best_so_far_individual;   /* struct that contains the best-so-far solution */
extern individual_struct *newIndividual;   /* struct that contains the new individuals in the GA */

extern double **comm_solution;   /* struct that contains solutions from Colonies */
extern double *best_solution_to_send;   /* struct that contains solution to be sent */
extern int *sorted_index;
extern int restart_iters;
extern int stall_iters;
extern int maxstall_iters;
extern int max_solutions;

extern double *breaks;
extern double *wheel1;
extern double *fitness;
extern int *sel;

extern int n_pop;      /* number of individuals */
extern double p_mutation;
extern double selPress;
extern int elitism;

extern double   **pheromone; /* pheromone matrix, two entries for each gate */
extern double   **total;     /* combination of pheromone times heuristic information */

extern double rho;           /* parameter for evaporation */
extern double alpha;         /* importance of trail */
extern double beta;          /* importance of heuristic evaluate */
extern double q_0;           /* probability of best choice in tour construction */

extern int as_flag;     /* = 1, run ant system */
extern int eas_flag;    /* = 1, run elitist ant system */
extern int mmas_flag;   /* = 1, run MAX-MIN ant system */

extern double   trail_max;       /* maximum pheromone trail in MMAS */
extern double   trail_min;       /* minimum pheromone trail in MMAS */
extern double   trail_0;         /* initial pheromone trail level */
extern int u_gb;            /* every u_gb iterations update with best-so-far ant */

extern int n; 		/* problem size */
extern double NAFac;
extern int timeIndex;
extern int sim_max_iter;
extern double sizeFac;
extern double NA_penalty;
extern double cycle_penalty;

extern int rho_flag;
extern int replace_best;
extern double solTol;

/*****************     Parallel   ***********************/
#ifdef MPI2
extern MPI_Request request[200][200];
extern MPI_Request Srequest;
extern MPI_Request SRrequest;
extern MPI_Status status;
extern int mpi_id;
extern int NPROC;
#endif

/***************************** IN-OUT **************************************/

#define LINE_BUF_LEN     255

struct point * read_etsp(const char *tsp_file_name);

extern int ntry;
extern int max_tries;

extern int evals;
extern int iteration;    /* iteration counter */
extern int best_iteration;
extern int max_iters;    /* maximum number of iterations */
extern double best_local_score;
extern int restart_best;
extern int n_restarts;

extern double   max_time;     /* maximal allowed run time  */
extern double   time_used;    /* time used until some given event */
extern double   time_passed;  /* time passed until some moment*/
extern double 	best_time;
extern double 	restart_time;

extern double optimal;      /* optimal solution value or bound to find */

extern FILE *report_cc, *report_iter, *report, *final_report, *results_report, *cc_results_report;

extern char name_buf[LINE_BUF_LEN];
extern int  opt;

/***************************** TIMER **************************************/

typedef enum type_timer {REAL, VIRTUAL} TIMER_TYPE;

/***************************** UTILITIES **************************************/

#define INFTY                 LONG_MAX

#define TRUE  1
#define FALSE 0

/* general macros */

#define MAX(x,y)        ((x)>=(y)?(x):(y))
#define MIN(x,y)        ((x)<=(y)?(x):(y))

#define DEBUG( x )

#define TRACE( x )


extern long int seed;

int ** generate_int_matrix( int n, int m);

double ** generate_double_matrix( int n, int m);

/********************************   Parallel ******************************/

void init_parallel(void);

void exit_parallel(void);

void sendBest(void);

void startComm(void);

void listen_ga(void);

void listen_aco(void);

void write_parallel_report(void);

void init_parallel_report(void);

/***************************** ACO **************************************/

void construct_solutions ( void );

void pheromone_trail_update ( void );

void as_update ( void );

void eas_update ( void );

void mmas_update ( void );

void check_pheromone_trail_limits( void );

void init_pheromone_trails ( double initial_trail );

void evaporation ( void );

void global_update_pheromone ( individual_struct *a );

void global_update_pheromone_weighted ( individual_struct *a, int weight );

void compute_total_information( void );

void select_gate( individual_struct *a, int phase );

/***************************** GA **************************************/

int termination_condition ( void );

void generate_new_pop ( void );

void reset_individuals ( void );

void init_optimization ( void );

void exit_optimization ( void );

void cellnopt ( void );

void update_statistics ( void );


/* Auxiliary procedures related to individuals */

int find_best ( void );

int find_worst( void );

void copy_from_to(individual_struct *a1, individual_struct *a2);

void sort_individuals( void );

void allocate_individuals( void );

/***************************** IN-OUT **************************************/

void set_default_parameters();

void read_parameters();

void in_out();

void init_report();

void write_report();

void print_parameters ( void );

void printSolution ( int *t);

void fprintSolution ( int *t);

void fprintSolutions ( void );

void fprintCCsolutions ( void );

void fprintCCsolution ( int *t );

/**********************  List  *************************/

void init_list( list *l );

int push_list( list *l, int *s, double sc);

int pop_list( list *l);

void destroy_list( list *l);

void check_and_push ( list *l, int *s, double sc);

int distance_between_solutions (int *a, int *b);

/***************************** TIMER **************************************/

void start_timers(void);

double elapsed_time(TIMER_TYPE type);


