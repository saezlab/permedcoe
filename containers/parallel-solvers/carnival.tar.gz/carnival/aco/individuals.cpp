/**
 * @file individuals.cpp
 * @author patricia.gonzalez@udc.es
 * @brief File contains procedures related with population
 */
 
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <assert.h>
#include <limits.h>
#include <time.h>
#include <mpi.h>
#include "aco.hpp"


list *listSolutions;

individual_struct *individual;
individual_struct *best_so_far_individual;
individual_struct *newIndividual;
double best_local_score;

double *breaks;
double *wheel1;
double *fitness;
int *sel;

int n_pop;      /* number of individuals */
double p_mutation;
double selPress;
int elitism;

int n;		/* problem size */
double NAFac;
int timeIndex;
int sim_max_iter;
double sizeFac;
double NA_penalty;
double cycle_penalty;

void allocate_individuals ( void )
/*    
      FUNCTION:       allocate the memory for the population, the new population and 
                      the best-so-far individual
      INPUT:          none
      OUTPUT:         none

*/
{
    int     i;
  
    /* population */
    if((individual = (individual_struct*) malloc(sizeof( individual_struct ) * n_pop +
		     sizeof(individual_struct *) * n_pop	 )) == NULL){
	printf("Out of memory, exit.");
	exit(1);
    }
    for ( i = 0 ; i < n_pop ; i++ ) {
        individual[i].solution        = (int*) calloc(n, sizeof(int));
    }

    /* best individual */
    if((best_so_far_individual = (individual_struct*) malloc(sizeof( individual_struct ) )) == NULL){
	printf("Out of memory, exit.");
	exit(1);
    }
    best_so_far_individual->solution        = (int*) calloc(n, sizeof(int));
  
    /* list of solutions */
    if((listSolutions = (list*) malloc(sizeof( list ) * max_solutions +
		     sizeof(list *) * max_solutions	 )) == NULL){
	printf("Out of memory, exit.");
	exit(1);
    }
     

}


void reset_individuals( void )
/*
 FUNCTION:       reset of population
 INPUT:          none
 OUTPUT:         none
 (SIDE)EFFECTS:  when finished, some individuals are initialized
 */
{
    int k, index, x;        /* counter variable */
    double time1, time2;
    
    /* ranking */
    sort_individuals();
    x = n_pop - ceil(n_pop/(n_restarts+1));
    
    #pragma omp parallel for private(k)
    for ( k = 0 ; k < x ; k++ ) {
        int rnd;
        index = sorted_index[k];
        for ( int j = 0 ; j < n ; j++ ) {
            rnd = round (genRand( &seedR )); /* random number 0 or 1 */
            individual[index].solution[j] = rnd;
        }
    }

}

    

int find_best( void )
/*    
      FUNCTION:       find the best individual of the current iteration
      INPUT:          none
      OUTPUT:         index of struct containing the iteration best individual
      (SIDE)EFFECTS:  none
*/
{
    double   min;
    int   k, k_min;

    min = individual[0].score;
    k_min = 0;
    for( k = 1 ; k < n_pop ; k++ ) {
	if( individual[k].score < min ) {
	    min = individual[k].score;
	    k_min = k;
	}
    }
    return k_min;
}



int find_worst( void )
/*    
      FUNCTION:       find the worst ant of the current iteration
      INPUT:          none
      OUTPUT:         pointer to struct containing iteration best ant
      (SIDE)EFFECTS:  none
*/
{
    double   max;
    int   k, k_max;

    max = individual[0].score;
    k_max = 0;
    for( k = 1 ; k < n_pop ; k++ ) {
	if( individual[k].score > max ) {
	    max = individual[k].score;
	    k_max = k;
	}
    }
    return k_max;
}


void copy_from_to(individual_struct *a1, individual_struct *a2)
{
/*    
      FUNCTION:       copy solution from a1 into a2
      INPUT:          pointers to the two individuals a1 and a2 
      OUTPUT:         none
      (SIDE)EFFECTS:  a2 is copy of a1
*/
    int   i;
  
    a2->score = a1->score;
    for ( i = 0 ; i < n ; i++ ) {
        a2->solution[i] = a1->solution[i];
    }
}




