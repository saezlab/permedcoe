/**
 * @file utilities.cpp
 * @author patricia.gonzalez@udc.es
 * @brief File contains in-out and other misc. procedures
 */

#ifdef MPI2
   #include <mpi.h>
#endif
#ifdef OMP
   #include <omp.h>
#endif
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include <sys/time.h>
#include <sys/resource.h>
#include "aco.hpp"

int max_tries;
int max_solutions;

int evals;
int iteration;         /* iteration counter */
int best_iteration;
int n_restarts;
int restart_best;
int restart_iters;
int maxstall_iters;
int stall_iters;

int max_iters;         /* maximum number of iterations */
long int seed;
MTRand seedR;

double   max_time;          /* maximal allowed run time of a try  */
double   time_used;         /* time used until some given event */
double   time_passed;       /* time passed until some moment*/
double 	 best_time;
double 	 restart_time;

double optimal;           /* optimal solution or bound to find */

int *sorted_index;

int rho_flag;
int replace_best;
double solTol;

/* ------------------------------------------------------------------------ */

FILE *report_cc, *report_iter, *report, *final_report, *cc_results_report, *results_report;

char name_buf[LINE_BUF_LEN];
int  opt;


/**************************   TIMER  ***************************************/
static struct rusage res;
static struct timeval tp;
static double virtual_time, real_time;

void start_timers(void)
/*
 FUNCTION:       virtual and real time of day are computed and stored to
 allow at later time the computation of the elapsed time
 (virtual or real)
 INPUT:          none
 OUTPUT:         none
 (SIDE)EFFECTS:  virtual and real time are computed
 */
{
    getrusage( RUSAGE_SELF, &res );
    virtual_time = (double) res.ru_utime.tv_sec +
    (double) res.ru_stime.tv_sec +
    (double) res.ru_utime.tv_usec / 1000000.0 +
    (double) res.ru_stime.tv_usec / 1000000.0;
    
    gettimeofday( &tp, NULL );
    real_time =    (double) tp.tv_sec +
    (double) tp.tv_usec / 1000000.0;
}



double elapsed_time(TIMER_TYPE type)
/*
 FUNCTION:       return the time used in seconds (virtual or real, depending on type)
 INPUT:          TIMER_TYPE (virtual or real time)
 OUTPUT:         seconds since last call to start_timers (virtual or real)
 (SIDE)EFFECTS:  none
 */
{
    if (type == REAL) {
        gettimeofday( &tp, NULL );
        return( (double) tp.tv_sec +
               (double) tp.tv_usec / 1000000.0
               - real_time );
    }
    else {
        getrusage( RUSAGE_SELF, &res );
        return( (double) res.ru_utime.tv_sec +
               (double) res.ru_stime.tv_sec +
               (double) res.ru_utime.tv_usec / 1000000.0 +
               (double) res.ru_stime.tv_usec / 1000000.0
               - virtual_time );
    }
    
}

/**************************   STATISTICS  ***************************************/

/* An implementation of the MT19937 Algorithm for the Mersenne Twister
 * by Evan Sultanik.  Based upon the pseudocode in: M. Matsumoto and
 * T. Nishimura, "Mersenne Twister: A 623-dimensionally
 * equidistributed uniform pseudorandom number generator," ACM
 * Transactions on Modeling and Computer Simulation Vol. 8, No. 1,
 * January pp.3-30 1998.
 *
 * http://www.sultanik.com/Mersenne_twister
 */

#define UPPER_MASK		0x80000000
#define LOWER_MASK		0x7fffffff
#define TEMPERING_MASK_B	0x9d2c5680
#define TEMPERING_MASK_C	0xefc60000


inline static void m_seedRand(MTRand* rand, unsigned long seed) {
    /* set initial seeds to mt[STATE_VECTOR_LENGTH] using the generator
     * from Line 25 of Table 1 in: Donald Knuth, "The Art of Computer
     * Programming," Vol. 2 (2nd Ed.) pp.102.
     */
    rand->mt[0] = seed & 0xffffffff;
    for(rand->index=1; rand->index<STATE_VECTOR_LENGTH; rand->index++) {
        rand->mt[rand->index] = (6069 * rand->mt[rand->index-1]) & 0xffffffff;
    }
}

/**
 * Creates a new random number generator from a given seed.
 */
MTRand seedRand(unsigned long seed) {
    MTRand rand;
    m_seedRand(&rand, seed);
    return rand;
}

/**
 * Generates a pseudo-randomly generated long.
 */
unsigned long genRandLong(MTRand* rand) {
    
    unsigned long y;
    static unsigned long mag[2] = {0x0, 0x9908b0df}; /* mag[x] = x * 0x9908b0df for x = 0,1 */
    if(rand->index >= STATE_VECTOR_LENGTH || rand->index < 0) {
        /* generate STATE_VECTOR_LENGTH words at a time */
        int kk;
        if(rand->index >= STATE_VECTOR_LENGTH+1 || rand->index < 0) {
            m_seedRand(rand, 4357);
        }
        for(kk=0; kk<STATE_VECTOR_LENGTH-STATE_VECTOR_M; kk++) {
            y = (rand->mt[kk] & UPPER_MASK) | (rand->mt[kk+1] & LOWER_MASK);
            rand->mt[kk] = rand->mt[kk+STATE_VECTOR_M] ^ (y >> 1) ^ mag[y & 0x1];
        }
        for(; kk<STATE_VECTOR_LENGTH-1; kk++) {
            y = (rand->mt[kk] & UPPER_MASK) | (rand->mt[kk+1] & LOWER_MASK);
            rand->mt[kk] = rand->mt[kk+(STATE_VECTOR_M-STATE_VECTOR_LENGTH)] ^ (y >> 1) ^ mag[y & 0x1];
        }
        y = (rand->mt[STATE_VECTOR_LENGTH-1] & UPPER_MASK) | (rand->mt[0] & LOWER_MASK);
        rand->mt[STATE_VECTOR_LENGTH-1] = rand->mt[STATE_VECTOR_M-1] ^ (y >> 1) ^ mag[y & 0x1];
        rand->index = 0;
    }
    y = rand->mt[rand->index++];
    y ^= (y >> 11);
    y ^= (y << 7) & TEMPERING_MASK_B;
    y ^= (y << 15) & TEMPERING_MASK_C;
    y ^= (y >> 18);
    return y;
}

/**
 * Generates a pseudo-randomly generated double in the range [0..1].
 */
double genRand(MTRand* rand) {
    return((double)genRandLong(rand) / (unsigned long)0xffffffff);
}


/********  matrix allocation  *******/

int ** generate_int_matrix( int n, int m)
/*    
      FUNCTION:       malloc a matrix and return pointer to it
      INPUT:          size of matrix as n x m 
      OUTPUT:         pointer to matrix
      (SIDE)EFFECTS:  
*/
{
  int i;
  int **matrix;

  if((matrix = (int**) malloc(sizeof(int) * n * m +
		      sizeof(int *) * n	 )) == NULL){
    printf("Out of memory, exit.");
    exit(1);
  }
  for ( i = 0 ; i < n ; i++ ) {
    matrix[i] = (int *)(matrix + n) + i*m;
  }

  return matrix;
}



double ** generate_double_matrix( int n, int m)
/*    
      FUNCTION:       malloc a matrix and return pointer to it
      INPUT:          size of matrix as n x m 
      OUTPUT:         pointer to matrix
      (SIDE)EFFECTS:  
*/
{

  int i;
  double **matrix;

  if((matrix = (double**) malloc(sizeof(double) * n * m +
		      sizeof(double *) * n	 )) == NULL){
    printf("Out of memory, exit.");
    exit(1);
  }
  for ( i = 0 ; i < n ; i++ ) {
    matrix[i] = (double *)(matrix + n) + i*m;
  }
  return matrix;
}


/*******  sort individuals *******/

void sort_individuals ( void )
/*
 FUNCTION:       sort population
 INPUT:          none
 OUTPUT:         none
 COMMENTS:       sorted_index is an array with the index of the individuals sorted
 */
{
    int     i, j;
    int     temp;

    for ( i = 0 ; i < n_pop ; i++ ) {
        sorted_index[i] = i;
    }
    
    for ( i = 0; i < (n_pop - 1) ; i++ ) {
        for ( j = i + 1 ; j < n_pop ; j++ ) {
            if (individual[sorted_index[j]].score > individual[sorted_index[i]].score)
            {
                temp = sorted_index[j];
                sorted_index[j] = sorted_index[i];
                sorted_index[i] = temp;
            } 
        } 
    }
    
}

/**************************   IN-OUT  ***************************************/

void read_parameters( void )
/*
 FUNCTION:       read input file,
 INPUT:          none
 OUTPUT:         none
 COMMENTS:
 */
{
    char texto[20];
    double numero;

    FILE *params;
    if ((params = fopen("parameters.txt", "r"))==NULL)
    	printf("Without parameters file => default parameters...\n");
    else {
    	while (fscanf(params, "%s %lf", texto, &numero) > 1)
     	{
        if ( !strcmp(texto,"max_tries") ) max_tries = (int)numero;
        else if( !strcmp(texto,"max_solutions") ) max_solutions = (int)numero;
        else if( !strcmp(texto,"rho_flag") ) rho_flag = (int)numero;
        else if( !strcmp(texto,"solTol") ) solTol = numero;
        else if( !strcmp(texto,"replace_best") ) replace_best = (int)numero;
	else if( !strcmp(texto,"n_pop") ) n_pop = (int)numero;
        else if( !strcmp(texto,"alpha") ) alpha = numero;
        else if( !strcmp(texto,"beta") ) beta = numero;
        else if( !strcmp(texto,"rho") ) rho = numero;
        else if( !strcmp(texto,"q_0") ) q_0 = numero;
        else if( !strcmp(texto,"restart_iters") ) restart_iters = (int)numero;
        else if( !strcmp(texto,"maxstall_iters") ) maxstall_iters = (int)numero;
        else if( !strcmp(texto,"as_flag") ) as_flag = (int)numero;
        else if( !strcmp(texto,"eas_flag") ) eas_flag = (int)numero;
        else if( !strcmp(texto,"mmas_flag") ) mmas_flag = (int)numero;
        else if( !strcmp(texto,"u_gb") ) u_gb = (int)numero;
        else if( !strcmp(texto,"max_iters") ) max_iters = (int)numero;
	else if( !strcmp(texto,"max_time") ) max_time = numero;
	else if( !strcmp(texto,"sim_max_iter") ) sim_max_iter = (int)numero;
        else if( !strcmp(texto,"optimal") ) optimal = numero;
        else if( !strcmp(texto,"selPress") ) selPress = numero;
        else if( !strcmp(texto,"elitism") ) elitism = (int)numero;
        else if( !strcmp(texto,"sizeFac") ) sizeFac = numero;
        else if( !strcmp(texto,"NA_penalty") ) NA_penalty = numero;
        else if( !strcmp(texto,"cycle_penalty") ) cycle_penalty = numero;
        else if( !strcmp(texto,"NAFac") ) NAFac = numero;
        else if( !strcmp(texto,"timeIndex") ) timeIndex = (int)numero;
        else if( !strcmp(texto,"seed") ) seed = (long int)numero;
	else printf(">>>>>>>>> Unknown parameter: %s\n",texto);
     	}
   
        
    fclose(params);
    }

}

void init_report( void )
/*
 FUNCTION:       prepare report file,
 INPUT:          none
 OUTPUT:         none
 COMMENTS:
 */
{
    char temp_buffer[LINE_BUF_LEN];

    sprintf(temp_buffer,"report_cc");
    report_cc = fopen(temp_buffer, "w");
    sprintf(temp_buffer,"conv_report_iter");
    report_iter = fopen(temp_buffer, "w");
    sprintf(temp_buffer,"conv_report");
    report = fopen(temp_buffer, "w");
    sprintf(temp_buffer,"cc_results_report");
    cc_results_report = fopen(temp_buffer, "w");
    sprintf(temp_buffer,"results_report");
    results_report = fopen(temp_buffer, "w");
    sprintf(temp_buffer,"final_report");
    final_report = fopen(temp_buffer, "w");

}


void set_default_parameters(void)
/*
 FUNCTION: set default parameter settings
 INPUT:    none
 OUTPUT:   none
 COMMENTS: none
 */
{
    max_tries	   = 3;
    sim_max_iter   = 100;

    sizeFac	   = 0.0001;
    NAFac	   = 1.0;
    NA_penalty	   = 100.0;
    cycle_penalty  = 100.0;
    timeIndex	   = 2;
    
    alpha          = 1.0;
    beta           = 2.0;
    rho            = 0.5;
    q_0            = 0.0;
    as_flag        = 0;
    eas_flag       = 0;
    mmas_flag      = 1;
    u_gb	   = 20;
    restart_iters  = 100;
    maxstall_iters  = 10000;

    seed           = (long int) time(NULL);
    max_time       = 100;
    max_iters      = 1000000;
    max_solutions  = 1;

    optimal        = 0.0;
    
    n_pop          = 50;
    selPress       = 1.2;
    p_mutation     = 0.2;
    elitism        = 5;
    
    rho_flag	   = 0;
    replace_best   = 0;
    solTol	   = 0.0;
}


void print_parameters()
/*
 FUNCTION: print parameter settings
 INPUT:    none
 OUTPUT:   none
 COMMENTS: none
 */
{
    printf("\n Parameter settings are:\n");
    printf("rho_flag\t\t %d\n", rho_flag);
    printf("solTol\t\t %f\n", solTol);
    printf("replace_best\t\t %d\n", replace_best);

    printf("max_solutions\t\t %d\n", max_solutions);
    printf("max_tries\t\t %d\n", max_tries);
    printf("max_iters\t\t %d\n", max_iters);
    printf("max_time\t\t %.2f\n", max_time);
    printf("seed\t\t\t %ld\n", seed);
    printf("optimum\t\t\t %f\n", optimal);
    
    printf("n_pop\t\t\t %d\n", n_pop);
    printf("alpha\t\t\t %.2f\n", alpha);
    printf("beta\t\t\t %.2f\n", beta);
    printf("rho\t\t\t %.2f\n", rho);
    printf("q_0\t\t\t %.2f\n", q_0);
    printf("as_flag\t\t\t %d\n", as_flag);
    printf("eas_flag\t\t %d\n", eas_flag);
    printf("mmas_flag\t\t %d\n", mmas_flag);
    printf("restart_iters\t\t %d\n", restart_iters);
    printf("maxstall_iters\t\t %d\n", maxstall_iters);
    printf("u_gb\t\t\t %d\n", u_gb);

}


void printSolution( int *t )
/*
 FUNCTION:       print the solution *t
 INPUT:          pointer to a solution
 OUTPUT:         none
 */
{
    int   i;
    
    printf("[ ");
    for( i = 0 ; i < n ; i++ ) {
        printf("%d ", t[i]);
    }
    printf(" ]\n");
}


void fprintSolution( int *t )
/*
 FUNCTION:       print the solution *t
 INPUT:          pointer to a solution
 OUTPUT:         none
 */
{
    int   i;

    if(results_report) {    
    	fprintf(results_report,"Try: %d, sol=[ ",ntry);
    	for( i = 0 ; i < n ; i++ ) {
        	fprintf(results_report,"%d ", t[i]);
    	}
    	fprintf(results_report," ]\n");
    }
}


void write_report( void )
/*
 FUNCTION:       write report file
 INPUT:          pointer to a solution
 OUTPUT:         none
 */
{
	int  i;

    if (final_report){
        fprintf(final_report,
                "Try %d:\t iteration %d\t time %f \t best %f \n ",
                ntry,best_iteration,best_time,best_so_far_individual->score);
    }
    fprintSolution(best_so_far_individual->solution);
    
    fflush(final_report);
    fflush(report_iter);
    fflush(report_cc);
    fflush(report);
    fflush(results_report);

}

/*************       LIST OF SOLUTIONS      ************/

void init_list(list *l) {
    l->first = NULL;
    l->last = NULL;
    l->size = 0;
}

int push_list ( list *l, int *sol, double sc) {
    int i;

    node *new_node;
    if ( (new_node = (node_struct *) malloc (sizeof (node_struct))) == NULL)
        return -1;
    if ((new_node->solution = (int *) malloc (n * sizeof (int))) == NULL)
        return -1;
    for ( i=0 ; i<n ; i++ ) new_node->solution[i] = sol[i];
    new_node->score = sc;
    new_node->next = l->first;
    l ->first = new_node;
    l ->size++;
    return 0;
}

int pop_list ( list *l ) {
    if ( l->size == 0 ) return -1;
    node *remove_node;
    remove_node = l->first;
    l->first = l->first->next;
    if(l->size ==1) l->last = NULL;
    free(remove_node->solution);
    free(remove_node);
    l->size--;
    return 0;
}

void destroy_list ( list *l) {
    while ( l->size >0 ) pop_list( l );
}

void fprintSolutions()
/*
 FUNCTION:       print the solution *t
 INPUT:          pointer to a solution
 OUTPUT:         none
 */
{
    int   i,j;
    node *nlist;
    
    nlist = listSolutions->first;
    
    if(results_report) {
        fprintf(results_report,"*********  TRY %d  **********\n",ntry);
        for( i = 0 ; i < listSolutions->size ; i++ ) {
            fprintf(results_report,"score: \t %.12f \t = \t [ ",nlist->score);
            for( j = 0 ; j < n ; j++ ) {
                fprintf(results_report,"%d ", nlist->solution[j]);
            }
            fprintf(results_report," ]\n");
            nlist = nlist->next;
        }
    }
}

void fprintCCsolutions()
/*
 FUNCTION:       print the solution *t
 INPUT:          pointer to a solution
 OUTPUT:         none
 */
{
    int   i,j;
    
    if(cc_results_report) {
            fprintf(cc_results_report,"score: \t %.12f \t = \t [ ",best_so_far_individual->score);
            for( j = 0 ; j < n ; j++ ) {
	        fprintf(cc_results_report,"\t %d", best_so_far_individual->solution[j]);
            }
            fprintf(cc_results_report," \t ]\n");
        }
    
}

void fprintCCsolution( int *t )
/*
 FUNCTION:       print the solution *t
 INPUT:          pointer to a solution
 OUTPUT:         none
 */
{
    int   i;

    if(cc_results_report) {    
    	fprintf(cc_results_report,"Iter: \t%d\t, sol=[ ",iteration);
    	for( i = 0 ; i < n ; i++ ) {
        	fprintf(cc_results_report,"\t%d ", t[i]);
    	}
    	fprintf(cc_results_report,"\t ]\n");
    }
}


