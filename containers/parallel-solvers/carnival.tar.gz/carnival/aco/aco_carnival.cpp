/**
 * ACO for Carnival simulator
 *
 * @file aco_carnival.cpp
 * @author patricia.gonzalez@udc.es
 * @brief File contains main procedures
 *
 */

#ifdef OMP
   #include <omp.h>
#endif
#ifdef MPI2
   #include <mpi.h>
#endif

#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <stdexcept>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include <sys/time.h>
#include <sys/resource.h>

#include "vector_funcs.hpp"
#include "data.hpp"
#include "carnival_data.hpp"
#include "compute_score_t1_carnival.hpp"
#include "aco.hpp"

using std::cout;
using std::endl;

int ntry;



/*************************    ACO procedures  *****************************/

void construct_solutions( void )
/*
 FUNCTION:       manage the solution construction phase
 INPUT:          none
 OUTPUT:         none
 (SIDE)EFFECTS:  when finished, all ants of the colony have constructed a solution
 */
{
    int k;        /* counter variable */
    double time1, time2;
    
    //    time1 = elapsed_time(REAL);
    #pragma omp parallel for private(k)
    for ( k = 0 ; k < n_pop ; k++ ) {
        int step = 0;
        while ( step < n ) {
            select_gate( &individual[k], step);
            step++;
        }
    }
    //    time2 = elapsed_time(REAL);
    //    printf("Time construction %f\n",time2-time1);
}



/*************************    common procedures  *****************************/

int termination_condition( void )
/*    
      FUNCTION:       checks whether termination condition is met 
      INPUT:          none
      OUTPUT:         0 if condition is not met, number neq 0 otherwise
      (SIDE)EFFECTS:  none
*/
{
  return ( ((iteration >= max_iters) || (elapsed_time( REAL ) >= max_time)) ||
	  (best_so_far_individual->score <= optimal && max_solutions <= listSolutions->size) || (stall_iters > maxstall_iters));
}


void compute_scores( double(*obj_function)(const Carnival_data&,std::vector<int>&,int,double,double,double,int),
                    const Carnival_data& user_data)
/*
 FUNCTION:       compute scores
 INPUT:          none
 OUTPUT:         none
 */
{
    int k;        /* counter variable */
    double time1, time2;
    
        //time1 = elapsed_time(REAL);
    #pragma omp parallel for private(k)
    for ( k = 0 ; k < n_pop ; k++ ) {
        std::vector<int> bs(n,0);
        int step = 0;
        while ( step < n ) {
            bs[step] = individual[k].solution[step];
            step++;
        }
        /* compute scores */
        individual[k].score = obj_function(user_data, bs, sim_max_iter, sizeFac, NA_penalty, cycle_penalty, timeIndex);
    }
    evals = evals + n_pop;

        //time2 = elapsed_time(REAL);
}


void init_individuals( double(*obj_function)(const Carnival_data&,std::vector<int>&,int,double,double,double,int),
                      const Carnival_data& user_data)
/*
 FUNCTION:       initialization of population
 INPUT:          none
 OUTPUT:         none
 (SIDE)EFFECTS:  when finished, all individuals are initialized
 */
{
    int k;        /* counter variable */
    double time1, time2;
    
    //    time1 = elapsed_time(REAL);
    /* solution for individuals initialized randomly */
    #pragma omp parallel for private(k)
    for ( k = 0 ; k < n_pop ; k++ ) {
        std::vector<int> bs(n,0);
        int rnd;
        for ( int j = 0 ; j < n ; j++ ) {
            rnd = round (genRand( &seedR )); /* random number 0 or 1 */
            individual[k].solution[j] = rnd;
            bs[j] = rnd;
        }
        individual[k].score = obj_function(user_data, bs, sim_max_iter, sizeFac, NA_penalty, cycle_penalty, timeIndex);
    }
    evals = evals + n_pop;

    //    time2 = elapsed_time(REAL);
    //    printf("Time construction %f\n",time2-time1);
    
}


void init_optimization( void )
/*    
      FUNCTION: initilialize variables appropriately when starting a trial
      INPUT:    none
      OUTPUT:   none
      COMMENTS: none
*/
{

    /* Allocate individuals */
    allocate_individuals();

    /* Initialize variables concerning statistics etc. */
    evals  = 0;
    iteration    = 1;
    best_iteration = 1;
    best_so_far_individual->score = INFTY;
    
    init_list(listSolutions);
    
    start_timers();
    best_time = 0.0;
    time_used = elapsed_time( REAL );
    time_passed = time_used;
    stall_iters = 0;
  
    printf("*********** Try: %d *****************\n",ntry); 
    if (report) fprintf(report,"******** Try: %d **********\n",ntry);
    if (report_iter) fprintf(report_iter,"******** Try: %d **********\n",ntry);
    if (report_cc) fprintf(report_cc,"\n",ntry);
   
    /* Allocate communication buffers */
    startComm ( );
    
    restart_best = 1;
    n_restarts = 0;
        
    /* allocate pheromone matrix */
    pheromone = generate_double_matrix( n, 2 );
    total = generate_double_matrix( n, 2 );
        
    /* Initialize pheromone trails */
    trail_max = 1. / ( (rho) * 0.5 );
    trail_min = trail_max / ( 2. * n );
    trail_0 = trail_max;
    init_pheromone_trails( trail_0 );

 
}

void exit_optimization( void )
/*
 FUNCTION: end trial
 INPUT:    none
 OUTPUT:   none
 COMMENTS: none
 */
{
 
    int     i;

    printf("*********** exit proc: %d *****************\n", mpi_id);
#ifdef MPI2
    write_parallel_report ( );
    exit_parallel ( );
#else
    write_report ( );
#endif
    
    destroy_list(listSolutions);

    for ( i = 0 ; i < n_pop ; i++ )
        free( individual[i].solution );
    free( individual );
    free( best_so_far_individual->solution );
    
    free( pheromone );
    free( total );


}
    
void update_statistics( void )
/*    
      FUNCTION:       manage some statistical information
                      if a new best solution is found
      INPUT:          none
      OUTPUT:         none
 
*/
{

    int i, iteration_best;
    double diff;

    iteration_best = find_best(); /* iteration_best_ant is a global variable */
 
      //  fprintCCsolution(individual[iteration_best].solution);
/* 
    if(iteration == 2 || (!(iteration % 10) && iteration < 50) || (!(iteration % 100) && iteration <1600)) {
	if(report_cc) fprintf(report_cc,"%.12f \t ",best_so_far_individual->score);
    }*/
     
    if ( individual[iteration_best].score < best_so_far_individual->score ) {
        
        diff = best_so_far_individual->score - individual[iteration_best].score;
        time_used = elapsed_time( REAL ); /* best sol found after time_used */
        copy_from_to( &individual[iteration_best], best_so_far_individual );
        best_local_score = best_so_far_individual->score;
	
	/* Send best to the rest of the Colonies */
#ifdef MPI2
        sendBest ( );
#endif

        if ( report ) fprintf(report,"%f \t %f\n",best_so_far_individual->score,elapsed_time(REAL));
        if ( report_iter ) fprintf(report_iter,"%f \t %d\n",best_so_far_individual->score,evals);

        best_iteration = iteration;
        best_time = time_used;
        stall_iters = 0;
        restart_best = iteration;
        
        trail_max = 1. / ( (rho) * best_so_far_individual->score );
       	trail_min = trail_max / ( 2. * n );
       	trail_0 = trail_max;
        
        /* reset list of solutions */
	if (diff < ( solTol * best_so_far_individual->score ) ) {
           push_list(listSolutions,best_so_far_individual->solution,best_so_far_individual->score);
	}
	else {
           destroy_list(listSolutions);
           push_list(listSolutions,best_so_far_individual->solution,best_so_far_individual->score);
    	} 
    }
    else {
        stall_iters++;
        if (individual[iteration_best].score == best_so_far_individual->score ) {
	    check_and_push(listSolutions,individual[iteration_best].solution,individual[iteration_best].score);
        }
    }
    
    
  
    if (rho_flag) {
        if ((iteration - restart_best) < (int) (restart_iters * 0.1)) rho = 0.8;
        else if ((iteration - restart_best) < (int) (restart_iters * 0.25)) rho = 0.5;
        else if ((iteration - restart_best) < (int) (restart_iters * 0.5)) rho = 0.3;
        else if ((iteration - restart_best) < (int) (restart_iters * 0.75)) rho = 0.2;
        else rho = 0.1;
     }
       
    if ( iteration - restart_best > restart_iters ) {
         n_restarts++;
	 init_pheromone_trails( trail_0 );
         compute_total_information();
         restart_best = iteration;
         restart_time = elapsed_time( REAL );
     }
   

}

/*************************    OPT main    *********************************/

double opt_algorithm_aco(int n_vars,
                     double(*obj_function)(const Carnival_data&,std::vector<int>&,int,double,double,double,int),
                     const Carnival_data& user_data){
    
    int     k;
    double  score;
    double  time0,time1, time2,time3,time4;
    
    n = n_vars;
    
    init_optimization();
    
    /* First iteration */
    init_individuals(obj_function, user_data);
    update_statistics();
    pheromone_trail_update();
    
    /* next iterations */
    while ( !termination_condition() ) {
        iteration++;
        time0 = elapsed_time(REAL);
        construct_solutions();
        time1 = elapsed_time(REAL);
        compute_scores(obj_function, user_data);
        time2 = elapsed_time(REAL);
        update_statistics();
        time3 = elapsed_time(REAL);
        pheromone_trail_update();
        time4 = elapsed_time(REAL);
    }	
    
    //if(mpi_id == 0) printf("Time construction %f, compute_scores %f, statistics %f, update_pheromone %f\n",time1-time0,time2-time1,time3-time2, time4-time3);
    score = best_so_far_individual->score;
    exit_optimization();
    return(score);
}




/*************************    MAIN    *********************************/
/*
 This function currently requires a single hdf5 input file that describes the model.
 */


int main(int argc, char **argv) {
    

    /** MPI Initialization **/
#ifdef MPI2    
    init_parallel ( );
    init_parallel_report ( );
#else
    init_report ( );
#endif
    
    /* parameters can be read from a txt file */
    set_default_parameters ( );
    read_parameters ( );
    print_parameters ( );

    if (argc < 1) throw std::runtime_error("Need an input file (hdf5 description of the model");
    
    // variable `model` stores the description of the model,
    // all data that needed for cost function computation
    auto model = Carnival_data(std::string(argv[1]));
    double opt_results;
    double n_optim_variables = model.nReacs;
    
    /* Random numbers */
    int seed1 = seed * (mpi_id+1);
    seedR = seedRand ( seed1 );

    for ( ntry = 0 ; ntry < max_tries ; ntry++ ) {
		 	opt_results = opt_algorithm_aco(n_optim_variables, &compute_score_t1_carnival, model);
    }

#ifdef MPI2    
    MPI_Finalize();
#endif

}
