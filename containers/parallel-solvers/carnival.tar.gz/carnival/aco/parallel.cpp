/**
 * @file parallel.c
 * @author Patricia
 * @brief File containing general functions about the parallelization of the 
 * algorithm with MPI.
 */

#include <signal.h>
#include <mpi.h>
#include <omp.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <assert.h>
#include <limits.h>
#include <time.h>
#include "aco.hpp"

MPI_Request request[200][200];
MPI_Request Srequest;
MPI_Request SRrequest;
MPI_Status status;

int mpi_id;
int NPROC;

double **comm_solution;
double *best_solution_to_send;

void init_parallel ( void )
{
 
    MPI_Init(NULL,NULL);
 
    MPI_Comm_rank(MPI_COMM_WORLD, &mpi_id);
    MPI_Comm_size(MPI_COMM_WORLD, &NPROC);

}


/**
 Routine to start recv. of communications from Colonies
 **/

void startComm ( void )
{
    int i;
    
    /* Allocation of the communication buffers */
    if ((comm_solution = (double **) malloc(sizeof(double *)*NPROC))==NULL) {
        printf("Comm Solution. Out of memory, exit.");
        exit(1);
    }
    for ( i = 0 ; i < NPROC ; i++ )
        comm_solution[i] = (double *) malloc(sizeof(double)*(n+1));
    
    if ((best_solution_to_send = (double *) malloc(sizeof(double)*(n+1)))==NULL) {
        printf("Best solution to send. Out of memory, exit.");
        exit(1);
    }

    
    /* Prepare to receive the best solutions found in
     the rest of the colonies */
    for (i=0 ; i<NPROC ; i++)
        if (i!=mpi_id)
   		MPI_Irecv(&comm_solution[i][0], n+1, MPI_DOUBLE, i,
        	      3000, MPI_COMM_WORLD, &request[i][ntry]);
    
}


/**
 Routine to send the best solution found to the rest of Colonies
 **/
void sendBest ( void )
{
    int     i;
    
    for ( i = 0; i < n; i++)
        best_solution_to_send[i] = (double) best_so_far_individual->solution[i];
    best_solution_to_send[n] = best_so_far_individual->score;

 // printf(">>>>> >>>> >>>>> ntry %d iter %d ID: %d, isend %f \n",ntry,iteration,mpi_id,best_so_far_individual->score);
   
   /* Send best solution found to the rest of the colonies */
    
    for( i = 0 ; i < NPROC ; i++ )
       if ( i != mpi_id ){
           MPI_Isend(best_solution_to_send, n+1, MPI_DOUBLE, i,
                     3000, MPI_COMM_WORLD, &Srequest);
        }
}

/**
 Routine to check if there are pending messages from Colonies
 **/
void listen_ga()
{
    int         i, j;
    int         listen;
    int         replace_index;
    int         *fsolution;
    double      diff;

    if (replace_best) replace_index = n_pop-1;
    else replace_index = 0;

    /* Loop to listen best solutions from colonies */
    for( i = 0; i < NPROC ; i++) {
        
      if( i != mpi_id ){
          
        listen = 1;
          
        while ( listen == 1 ) {
            MPI_Test(&request[i][ntry], &listen, &status);
        
            if ( listen ) {
              //printf(" ntry %d iter %d ID: %d Recibido best: %f, del %d <<<<<<<<   <<<<<<<   <<<<<<<<\n",ntry,iteration,
	      	//		mpi_id,comm_solution[status.MPI_SOURCE][n], status.MPI_SOURCE);
            
              if ( comm_solution[status.MPI_SOURCE][n] < best_so_far_individual->score) {
	            diff = best_so_far_individual->score - comm_solution[status.MPI_SOURCE][n];   
                    best_so_far_individual->score = comm_solution[status.MPI_SOURCE][n];
                    for ( j = 0 ; j < n ; j++ )
                	    best_so_far_individual->solution[j] = (int) comm_solution[status.MPI_SOURCE][j];
                  
                    /* replace best/worst individuals with new global best individual so far */
                    copy_from_to( best_so_far_individual, &individual[sorted_index[replace_index]] );
		            if (replace_best) replace_index--;
		            else replace_index++;
        
                    if ( report ) fprintf(report,"%f \t %f\n",best_so_far_individual->score,elapsed_time(REAL));
                    if ( report_iter ) fprintf(report_iter,"%f \t %d\n",best_so_far_individual->score,evals);
                  
		    if ( diff < (solTol * best_so_far_individual->score) ) {
                        push_list(listSolutions,best_so_far_individual->solution,best_so_far_individual->score);
	       	    }
		    else {
                        destroy_list(listSolutions);
                        push_list(listSolutions,best_so_far_individual->solution,best_so_far_individual->score);
		    }
                  

              }
             
              if ( comm_solution[status.MPI_SOURCE][n] == best_so_far_individual->score) {
                    fsolution = (int *) malloc(sizeof(int)*n);
                    for ( j = 0 ; j < n ; j++ )
                        fsolution[j] = (int) comm_solution[status.MPI_SOURCE][j];
                    check_and_push(listSolutions, fsolution, comm_solution[status.MPI_SOURCE][n]);
                    free(fsolution);
               }

            /* Prepare to receive more solutions */
               MPI_Irecv(&comm_solution[status.MPI_SOURCE][0], n+1, MPI_DOUBLE,
                      status.MPI_SOURCE, 3000, MPI_COMM_WORLD, &request[i][ntry]);
            
            }
        }
      }
    }
    
}

void listen_aco()
{
    int         i, j;
    int         listen;
    int         *fsolution;
    double      diff;
    
    /* Loop to listen best solutions from colonies */
    for( i = 0; i < NPROC ; i++) {
        
        if( i != mpi_id ){
            
            listen = 1;
            
            while ( listen == 1 ) {
                MPI_Test(&request[i][ntry], &listen, &status);
                
                if ( listen ) {
                    //printf(" ntry %d iter %d ID: %d Recibido best: %f, del %d <<<<<<<<   <<<<<<<   <<<<<<<<\n",ntry,iteration,
                    //		mpi_id,comm_solution[status.MPI_SOURCE][n], status.MPI_SOURCE);
                    
                    if ( comm_solution[status.MPI_SOURCE][n] < best_so_far_individual->score) {
	                diff = best_so_far_individual->score - comm_solution[status.MPI_SOURCE][n];   
                        
                        best_so_far_individual->score = comm_solution[status.MPI_SOURCE][n];
                        for ( j = 0 ; j < n ; j++ )
                            best_so_far_individual->solution[j] = (int) comm_solution[status.MPI_SOURCE][j];
                        
                        trail_max = 1. / ( (rho) * best_so_far_individual->score );
                        trail_min = trail_max / ( 2. * n );
                        trail_0 = trail_max;
                        
                        if ( report ) fprintf(report,"%f \t %f\n",best_so_far_individual->score,elapsed_time(REAL));
                        if ( report_iter ) fprintf(report_iter,"%f \t %d\n",best_so_far_individual->score,evals);
                        
		        if ( diff < (solTol * best_so_far_individual->score) ) {
                             push_list(listSolutions,best_so_far_individual->solution,best_so_far_individual->score);
	       	        }
		        else {
                             destroy_list(listSolutions);
                             push_list(listSolutions,best_so_far_individual->solution,best_so_far_individual->score);
		        }
                        
                    }
                    if ( comm_solution[status.MPI_SOURCE][n] == best_so_far_individual->score) {
                        fsolution = (int *) malloc(sizeof(int)*n);
                        for ( j = 0 ; j < n ; j++ )
                            fsolution[j] = (int) comm_solution[status.MPI_SOURCE][j];
                        check_and_push(listSolutions, fsolution, comm_solution[status.MPI_SOURCE][n]);
                        free(fsolution);
                    }
                    
                    /* Prepare to receive more solutions */
                    MPI_Irecv(&comm_solution[status.MPI_SOURCE][0], n+1, MPI_DOUBLE,
                              status.MPI_SOURCE, 3000, MPI_COMM_WORLD, &request[i][ntry]);
                    
                }
            }
        }
    }
    
}


/**
 Routine to clear up pending messages in the asynchronous version
 **/
void exit_parallel ( void )
{
    int     i, listen, flag;
    
    MPI_Barrier(MPI_COMM_WORLD);
    
    /* Reception of lost pending messages */
    for( i = 0 ; i < NPROC ; i++ ) {
        if( i != mpi_id ){
            listen = 1;
	    while ( listen ) {
	   	 MPI_Test(&request[i][ntry], &listen, &status);
           	 if ( listen ){
                    //printf("Mensaje perdido de %d  ID; %d \n",status.MPI_SOURCE,mpi_id);
                    MPI_Irecv(&comm_solution[status.MPI_SOURCE][0], n+1, MPI_DOUBLE,
                            status.MPI_SOURCE, 3000, MPI_COMM_WORLD, &request[i][ntry]);
                 }
	    }
	MPI_Cancel(&request[i][ntry]);
        }

    }	
    MPI_Barrier(MPI_COMM_WORLD);

    for ( i = 0 ; i < NPROC ; i++ ) 
        free( comm_solution[i] );
    free(comm_solution);
    free(best_solution_to_send);
}
       

/***************************  Final MPI-Report ************************************/

void init_parallel_report( void )
/*
 FUNCTION:       prepare report file,
 INPUT:          none
 OUTPUT:         none
 COMMENTS:
 */
{
    char temp_buffer[LINE_BUF_LEN];

    if (mpi_id == 0 ) { 
        sprintf(temp_buffer,"report_cc");
        report_cc = fopen(temp_buffer, "w");
    	sprintf(temp_buffer,"conv_report.%dx%d",NPROC,omp_get_max_threads());
    	report = fopen(temp_buffer, "w");
    	sprintf(temp_buffer,"conv_report_iter.%dx%d",NPROC,omp_get_max_threads());
    	report_iter = fopen(temp_buffer, "w");
    	sprintf(temp_buffer,"final_report.%dx%d",NPROC,omp_get_max_threads());
    	final_report = fopen(temp_buffer, "w");
	fprintf(final_report,"Try:\t Best:\t bIter:\t bTime:\t Tot.Time:\t evals:\t nrestarts: \t nproc:\t \n");
    	sprintf(temp_buffer,"cc_results_report.%dx%d",NPROC,omp_get_max_threads());
    	cc_results_report = fopen(temp_buffer, "w");
    	sprintf(temp_buffer,"results_report.%dx%d",NPROC,omp_get_max_threads());
    	results_report = fopen(temp_buffer, "w");
    }

}


/**
 Routine to write one summarize mpi report
 **/
void write_parallel_report ( void )
{
    int     i, best_com_id;
    double    best_com_score, com_score, best_com_time, com_time;
    int     com_evals, com_iter, best_com_iter;
    
    best_com_score = best_local_score;
    best_com_iter = best_iteration;
    best_com_time = best_time;
    best_com_id = mpi_id;

    if( mpi_id == 0 ) {
        for( i=1 ; i<NPROC ; i++ ) {
              MPI_Recv(&com_score, 1, MPI_DOUBLE, i, 2000, MPI_COMM_WORLD, &status);
              MPI_Recv(&com_iter, 1, MPI_INT, i, 2000, MPI_COMM_WORLD, &status);
              MPI_Recv(&com_evals, 1, MPI_INT, i, 2000, MPI_COMM_WORLD, &status);
              MPI_Recv(&com_time, 1, MPI_DOUBLE, i, 2000, MPI_COMM_WORLD, &status);
            
	      evals = evals + com_evals;
              if ( com_score < best_com_score ) {
                    best_com_score = com_score;
                    best_com_iter = com_iter;
                    best_com_time = com_time;
                    best_com_id=i;
              }
	    
        }
 	if (final_report)
        	fprintf(final_report, "%d \t %.12f\t %d\t %f\t %f \t %d \t %d \t %d\n",
                	ntry, best_com_score, best_com_iter, best_com_time, elapsed_time( REAL ), evals, n_restarts, best_com_id);
        //fprintSolution(best_so_far_individual->solution);
        fprintSolutions();
        
		fflush(final_report);
		fflush(report_iter);
		fflush(report);
		fflush(results_report);
    } else {
        MPI_Isend(&best_com_score, 1, MPI_DOUBLE, 0, 2000, MPI_COMM_WORLD,&SRrequest);
        MPI_Isend(&best_com_iter, 1, MPI_INT, 0, 2000, MPI_COMM_WORLD,&SRrequest);
        MPI_Isend(&evals, 1, MPI_INT, 0, 2000, MPI_COMM_WORLD,&SRrequest);
        MPI_Isend(&best_com_time, 1, MPI_DOUBLE, 0, 2000, MPI_COMM_WORLD,&SRrequest);
    }
   
}

