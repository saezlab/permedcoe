# cellnopt C++ sandbox

## Purpose
This repo is hosting the development of the C++-based training of CellNOpt and CARNIVAL models.

## Content

* `/benchmark` folder contains the case studies
  * `/toymodel` simple network model with 12 nodes, 16 interactions
    * `ToyDataMMB.csv` experimental data for the model,
    * `ToyPKNMMB.sif` interaction network for the model,
    * `export_toymodel_to_hdf5.R` creates a CellNOpt-based model in R and exports to hdf5-file,
    * `toymodel.h5` hdf5 representation of the model,
    * `calibrate_toymodel_R.R` calibrattes the CellNOpt model using genetic algorithm,
    * `toymodel_calibration_R.txt` calibration results including time, optimal solution and objective function. 
* `/R` utility functions for the R code
  * `export_model_to_hdf5.R` exports a CellNopt-based model to hdf5 format
* `/src` C++ code
  * `compute_score_t1.hpp` calls `simulator` and `get_fit` functions
  * `data.hpp` class that reads the HDF5 files generated in R
  * `get_fit.hpp` function that calculates the score 
  * `simulator.hpp` simulates given a bit string
  * `vector_funcs.hpp` helper functions for vector and matricies
* `CMakeLists.txt` for building C++ code
* `Makefile` for running tests
* `conda_env.yml` conda environment specification to ensure reproducibility

## Setup

To download this repository execute the following command:
```
git clone --recursive https://github.com/saezlab/cellnopt_c_sandbox.git 
```
The recursive flag is needed for submodule `HighFive` which is used for reading HDF5 files.

There are two prerequisites: `cmake` and `hdf5`. Below are a couple of ways of installing the dependencies.

## OSX

To install the dependencies on OSX execute the following:
```
brew install hdf5 cmake
```

## Linux

To install the dependencies on linux (Debian-based) execute the following:
```
sudo apt install hdf5-tools cmake
```

## Conda

If conda is not installed on your system, install it by following the instructions [here](https://docs.conda.io/en/latest/miniconda.html). 

Next, execute the following to create an environment with cmake and hdf5 installed:
```
conda create -n cno_sandbox cmake hdf5
```
Then activate the environment:
```
conda activate cno_sandbox
```

## Example

### Comparison with R results
`test_compute_score_t1` compares the objective function calculation in C++ to the results obtained from an R optimization. 
To run the example, execute the following command:
```
make test_compute_score_t1
```
This will build and then run the executable `tests/test_compute_score_t1`.

### Optimization example
The example `examples/example1.cpp` contains a minimal code, how the optimization of these problems should be handled. 
It follows the following steps

1. the model data is imported
2. optimization function is called with the data and passing the objective function
3. the optimizer calls the objective fuction with a parameter vector (bitString) and model data
4. the optimizer reports the best score

To run the example, execute: 
```
make example1
```
This will build and then run the executable `build/example1`.

